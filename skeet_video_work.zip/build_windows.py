#!/usr/bin/env python3
"""Rebuild the supplied legacy CS:GO wrapper and its matching x86 loader.
Requires Python + ziglang==0.13.0, no MSVC SDK download.
"""
from pathlib import Path
import os
import subprocess
import sys
import ziglang

ROOT = Path(__file__).resolve().parent
ZIG = Path(ziglang.__file__).parent
BUILD = ROOT/'build'
BUILD.mkdir(exist_ok=True)
CACHE = ROOT/'.cache'
env = os.environ.copy()
env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(CACHE/'global'))
env.setdefault('ZIG_LOCAL_CACHE_DIR',str(CACHE/'local'))

def run(label, *args, cwd=ROOT):
    print(label,flush=True)
    log = BUILD/(label+'.log')
    with log.open('w') as output:
        proc = subprocess.run([sys.executable,'-m','ziglang',*map(str,args)],cwd=cwd,env=env,
                              stdout=output,stderr=subprocess.STDOUT)
    if proc.returncode:
        print(log.read_text(errors='replace')[-12000:])
        raise SystemExit(proc.returncode)

def main():
    subprocess.run([sys.executable,str(ROOT/'tools/build_ui_addon.py')],check=True)
    run('resources','rc','/fo',BUILD/'skeet.res','/I',ZIG/'lib/libc/include/any-windows-any',
        '/I',ROOT/'source/compat','skeet.rc',cwd=ROOT/'source/skeet')
    compatibility = [] if os.name == 'nt' else ['-I',ROOT/'source/compat']
    common = ['c++','-target','x86-windows-gnu','-std=c++23','-O1','-fms-extensions','-fasm-blocks',
              '-DUNICODE','-D_UNICODE','-D_CRT_SECURE_NO_WARNINGS',
              *compatibility,'-I',ROOT/'source/skeet']
    run('dll',*common,'-shared',ROOT/'source/skeet/skeet.cpp',ROOT/'source/skeet/saver.cpp',
        ROOT/'source/skeet/dllmain.cpp',BUILD/'skeet.res','-luser32','-ladvapi32','-lpsapi',
        '-o',BUILD/'skeet.dll')
    run('injector','c++','-target','x86-windows-gnu','-std=c++23','-O2','-DUNICODE','-D_UNICODE',
        *compatibility,'-municode',ROOT/'source/steam/steam.cpp','-ladvapi32','-o',BUILD/'injector.exe')
    run('probe','c++','-target','x86-windows-gnu','-std=c++17','-O2','-shared',
        *compatibility,ROOT/'tests/overlay_probe.cpp','-lkernel32','-o',BUILD/'overlay_probe.dll')
    print('Built build/skeet.dll + build/injector.exe (Windows x86). Runtime/game validation is separate.')
if __name__=='__main__': main()
