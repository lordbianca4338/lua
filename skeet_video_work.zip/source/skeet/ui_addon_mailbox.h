#pragma once
// Native UI models provide a synchronous, bounded bridge; Lua calls no C pointers.
namespace ui_addon::mailbox {
using namespace SkeetSDK;
inline Checkbox* request=nullptr;inline Slider* ready=nullptr;
inline Slider* inputs[32]{};inline Slider* outputs[8]{};
inline std::uint64_t revision=0;inline bool bound=false,busy=false;
inline int read(unsigned i){return i<32&&inputs[i]&&inputs[i]->Value?*inputs[i]->Value:0;}
inline void put(unsigned i,int value){if(i<8&&outputs[i]&&outputs[i]->Value)*outputs[i]->Value=value;}
inline int fixed(float value){if(!std::isfinite(value))return 0;return int(std::clamp(std::round(double(value)*10000.),-2147483647.,2147483647.));}
inline void __fastcall dispatch(void*,void*){
 if(!bound||busy)return;
 busy=true;for(unsigned i=0;i<7;i++)put(i,0);
 const auto sky_name=[](char (&text)[97]){for(unsigned n=0;n<24;n++){const auto v=static_cast<unsigned>(read(7+n));for(unsigned j=0;j<4;j++)text[n*4+j]=char((v>>(7*j))&127);}text[96]=0;};
 int result=1;
 switch(read(0)){
 case 0:result=8802;break;
 case 1:clover_ui_heartbeat();break;
 case 2:clover_ui_module(unsigned(read(1)));break;
 case 3:clover_night(read(1),unsigned(read(2)),unsigned(read(3)),unsigned(read(4)));break;
 case 4:clover_night_reset();break;
 case 5:{Telemetry t{};result=clover_telemetry(&t,sizeof(t));put(1,t.valid);put(2,fixed(t.cpu_percent));put(3,fixed(t.cpu_ghz));put(4,fixed(t.ram_used_gib));put(5,fixed(t.ram_total_gib));put(6,fixed(t.process_mib));break;}
 case 6:result=clover_selected_weapon();break;
 case 7:result=clover_sticker_set(read(1),unsigned(read(2)),read(3),read(4)/10000.f,read(5)/10000.f,read(6)/10000.f);break;
 case 8:{sticker_state::Sticker s{};result=clover_sticker_get(read(1),unsigned(read(2)),&s);put(1,s.id);put(2,fixed(s.wear));put(3,fixed(s.scale));put(4,fixed(s.rotation));break;}
 case 9:{char name[97]{};sky_name(name);result=clover_sky(name);break;}
 case 10:{char name[97]{};sky_name(name);result=clover_sky_tint(name[0]?name:nullptr,unsigned(read(1)));break;}
 default:result=0;break;
 }
 put(0,result);put(7,read(31));busy=false;
}
inline void frame(CMenu* menu){
 if(!menu||menu->Tabs.size()!=9)return;
 std::uint64_t hash=1469598103934665603ull;
 for(auto* tab:menu->Tabs)if(tab)for(auto* child:tab->Childs)if(child)for(auto* e:child->Elements)hash=(hash^reinterpret_cast<std::uintptr_t>(e))*1099511628211ull;
 if(hash==revision&&bound){bool linked=false;for(auto& c:request->Calls)if(c.ecx==nullptr&&c.function==&dispatch)linked=true;if(linked){if(ready&&ready->Value)*ready->Value=8802;return;}}
 revision=hash;bound=false;request=nullptr;ready=nullptr;for(auto& p:inputs)p=nullptr;for(auto& p:outputs)p=nullptr;
 for(auto* tab:menu->Tabs)if(tab)for(auto* child:tab->Childs)if(child)for(auto* e:child->Elements){
  if(!e)continue;
  auto* c=e->GetAs<Checkbox>();if(c->Header.Type!=UiCheckbox&&c->Header.Type!=UiSlider)continue;
  wchar_t name[128]{};native_ui_names::decode(c->Name.get(),name,128);
  if(!std::wcscmp(name,L"Clover bridge request 8802")&&c->Header.Type==UiCheckbox)request=c;
  else if(c->Header.Type==UiSlider){auto* s=e->GetAs<Slider>();
   if(!std::wcscmp(name,L"Clover bridge ready 8802"))ready=s;
   const auto index=[](const wchar_t* p,unsigned limit){if(!*p)return limit;unsigned value=0;for(;*p;++p){if(*p<L'0'||*p>L'9')return limit;value=value*10+unsigned(*p-L'0');if(value>=limit)return limit;}return value;};
   if(!std::memcmp(name,L"Clover bridge in ",17*sizeof(wchar_t))){const auto i=index(name+17,32);if(i<32)inputs[i]=s;}
   if(!std::memcmp(name,L"Clover bridge out ",18*sizeof(wchar_t))){const auto i=index(name+18,8);if(i<8)outputs[i]=s;}
  }
 }
 if(!request||!request->Value||!ready||!ready->Value)return;
 for(auto* s:inputs)if(!s||!s->Value)return;
 for(auto* s:outputs)if(!s||!s->Value)return;
 bool linked=false;for(auto& call:request->Calls)if(call.ecx==nullptr&&call.function==&dispatch)linked=true;
 if(!linked)request->Calls.emplace_back(nullptr,&dispatch);
 bound=true;*ready->Value=8802;
}
}
