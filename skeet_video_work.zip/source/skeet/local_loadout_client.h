#pragma once
#include "local_loadout.h"
#include "local_inventory_client.h"
namespace local_loadout_client {
using namespace local_inventory_client;
inline bool compatible() {
 if(!local_inventory_client::ready())return false;
 constexpr unsigned char equip[]={0x55,0x8b,0xec,0x8b,0x45,8,0x8b,0xd0,0xc1,0xea,0x10};
 constexpr unsigned char setter[]={0x55,0x8b,0xec,0x83,0xec,8,0x53,0x8b,0x5d,8};
 return !std::memcmp(base+0x6d92b0,equip,sizeof(equip))&&!std::memcmp(base+0x6cba60,setter,sizeof(setter));
}
inline bool current(const Session& s){Session next{};return compatible()&&session(next)&&next==s;}
inline bool event_api() {
 auto* object=memory(base+0x534d810,4)?pointer(base+0x534d810,0):nullptr;if(!memory(object,4))return false;
 auto* table=pointer(object,0);if(!memory(table,55*4))return false;
 for(unsigned slot:{52u,54u}){MEMORY_BASIC_INFORMATION info{};auto* fn=pointer(table,slot*4);if(!VirtualQuery(fn,&info,sizeof(info))||!(info.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY)))return false;}
 return true;
}
inline bool owned(const Session& s,const Item& i){return contains(s,i.object,i.id);}
inline int slot(const Session& s,const Item& i,int team) {
 if((team!=2&&team!=3)||!owned(s,i)||!event_api())return -1;
 auto* sch=schema();auto* getter=method(sch,4);if(!getter)return -1;
 using Def=void*(__thiscall*)(void*,int);auto* def=reinterpret_cast<Def>(getter)(sch,i.spec.weapon);
 if(!memory(def,0x2a0))return -1;
 const auto teams=read32(def,0x288);const bool agent=(i.spec.flags&2u)&&agent_definition(def);
 if(!(teams&(1u<<team))&&!(agent&&teams==0))return -1;
 auto result=definition_slot(def,team);
 if(agent&&result<0&&definition_slot(def,0)==38)result=38;
 return result>=0&&result<57?result:-1;
}
inline bool get(const Session& s,int team,int slot,std::uint64_t& id) {
 if(team<2||team>3||slot<0||slot>=57||!memory(s.inventory,0xd8+4*57*8))return false;
 id=read64(s.inventory,0xd8+(team*57+slot)*8);return true;
}
inline bool state(const Session& s,const Item& item,int team,int slot) {
 if(!owned(s,item)||(team!=2&&team!=3)||(slot!=0xffff&&(slot<0||slot>=57)))return false;
 using Set=void(__thiscall*)(void*,unsigned);reinterpret_cast<Set>(base+0x6d92b0)(item.object,(unsigned(slot)<<16)|unsigned(team));
 // Only the owned synthetic EconItem's state changes. Existing Steam items
 // retain their SO equipped state; only local loadout lookup is overlaid.
 return notify(s,1,item.object);
}
inline bool set(const Session& s,int team,int slot,std::uint64_t id) {
 std::uint64_t old=0;if(!get(s,team,slot,old)||!memory(s.inventory,0xd8+4*57*8,true))return false;
 if(!event_api())return false;
 // Original local-array setter also emits Panorama's loadout-item-changed
 // event. InventoryManager methods 20/29 (GC equip) are never invoked.
 using Set=void(__thiscall*)(void*,int,std::uint64_t);
 auto* row=static_cast<unsigned char*>(s.inventory)+0xd8+team*57*8;
 reinterpret_cast<Set>(base+0x6cba60)(row,slot,id);
 std::uint64_t result=0;return get(s,team,slot,result)&&result==id;
}
inline bool clear(const Session& s,const Item& item) {
 if(!compatible()||!owned(s,item))return false;using Set=void(__thiscall*)(void*,unsigned);
 // Clear the owned SO's equipped flags before its SODestroyed notification;
 // otherwise an old item could clear the new/restored loadout in that callback.
 for(unsigned team:{2u,3u})reinterpret_cast<Set>(base+0x6d92b0)(item.object,0xffff0000u|team);
 return true;
}
inline const local_loadout::Api api{&current,&owned,&slot,&get,&state,&set,&clear};
}
