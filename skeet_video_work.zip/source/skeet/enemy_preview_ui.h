#pragma once
// Owned render/input layer; all ordinary ESP choices use original native models.
namespace enemy_preview {
using namespace menu_interaction;
inline SkeetSDK::IRenderer* draw_renderer=nullptr;
inline Preview plan{};inline bool shown=false,settings_open=false,loaded=false;
inline int color_item=-1,color_drag=-1;
inline int drag=-1,scroll=0;inline unsigned drag_before=0;inline ui_preview_input::Poll input{};
inline Rect labels[flag_count]{};inline bool enabled_flags[flag_count]{};
inline const wchar_t* basic_names[]={L"Bounding box",L"Name",L"Health bar",L"Ammo",L"Skeleton",L"Weapon icon",L"Weapon text",L"Distance",L"Money"};
inline Binding* find(const wchar_t* name,int type,int panel=EnemyESP){
 if(!attached||captured_topology!=topology())return nullptr;
 for(unsigned i=0;i<binding_count;i++){auto& b=bindings[i];if(b.group->panel==panel&&b.source->GetAs<Checkbox>()->Header.Type==type&&eq(b.name,name))return &b;}return nullptr;
}
inline bool checked(const wchar_t* name,int panel=EnemyESP){auto* b=find(name,UiCheckbox,panel);return b&&b->source->GetAs<Checkbox>()->Value&&*b->source->GetAs<Checkbox>()->Value;}
inline void toggle(Binding* b){if(!b)return;auto* s=b->source->GetAs<Checkbox>();if(!s->Value||!s->Header.Flags.Editable)return;*s->Value=!*s->Value;changed(b,nullptr);}
inline unsigned tint(const wchar_t* anchor,int panel,unsigned fallback){
 if(!attached||captured_topology!=topology())return fallback;
 for(unsigned i=0;i<binding_count;i++){auto& b=bindings[i];if(b.group->panel==panel&&eq(b.anchor,anchor)&&b.source->GetAs<Checkbox>()->Header.Type==UiColorPicker){auto* p=native_ui_proxy::pointer(b.source,0x5c);if(p){unsigned c;std::memcpy(&c,p,4);return c;}}}return fallback;
}
inline Binding* color_source(const wchar_t* anchor){
 if(!attached||captured_topology!=topology())return nullptr;
 for(unsigned i=0;i<binding_count;i++){auto& b=bindings[i];if(b.group->panel==EnemyESP&&eq(b.anchor,anchor)&&b.source->GetAs<Checkbox>()->Header.Type==UiColorPicker)return &b;}return nullptr;
}
inline bool set_color(const wchar_t* anchor,unsigned value){auto* b=color_source(anchor);if(!b)return false;auto* s=b->source->GetAs<Checkbox>();auto* data=native_ui_proxy::pointer(s,0x5c);if(!data||!s->Header.Flags.Editable)return false;std::memcpy(data,&value,4);changed(b,nullptr);return true;}
struct FlagSource {Binding* binding=nullptr;unsigned bit=0;};
inline FlagSource flags[flag_count]{};
inline void flag_sources(){
 for(int i=0;i<flag_count;i++){flags[i]={};enabled_flags[i]=false;}
 auto* b=find(L"Flags",UiMultiselect);if(b){auto* m=b->source->GetAs<Multiselect>();if(m->Value&&m->Vars.size()<=32)for(auto& var:m->Vars){
  const unsigned mask=unsigned(var.Index);if(!mask||(mask&(mask-1))||var.Name.size()>64)continue;wchar_t n[65]{};unsigned used=0;for(auto c:var.Name){if(!c||used>=64)break;n[used++]=static_cast<unsigned char>(c);}const int id=flag(n);if(id>=0){flags[id]={b,mask};enabled_flags[id]=(unsigned(*m->Value)&flags[id].bit)!=0;}
 }}
 if(!flags[0].binding)enabled_flags[0]=checked(L"Money");
 if(!flags[10].binding)enabled_flags[10]=esp_layout_runtime::show_hit;
}
inline void toggle_flag(int id){
 auto f=flags[id];if(!f.binding){if(id==0)toggle(find(L"Money",UiCheckbox));if(id==10)esp_layout_runtime::show_hit=!esp_layout_runtime::show_hit;return;}
 auto* m=f.binding->source->GetAs<Multiselect>();if(!m->Value||!m->Header.Flags.Editable)return;unsigned n=unsigned(*m->Value)^f.bit;if(!n&&m->NotNull)return;*m->Value=int(n);changed(f.binding,nullptr);
}
inline void persistence(bool save){
 wchar_t folder[MAX_PATH]{};const auto n=GetEnvironmentVariableW(L"LOCALAPPDATA",folder,MAX_PATH);if(!n||n+40>=MAX_PATH)return;
 std::wcscat(folder,L"\\SkeetLegacy");if(save)CreateDirectoryW(folder,nullptr);std::wstring path=folder;path+=L"\\esp_layout.ini";
 if(save){for(int i=0;i<flag_count;i++){const std::wstring key=L"flag"+std::to_wstring(i),value=std::to_wstring(placements[i].load());WritePrivateProfileStringW(L"layout",key.c_str(),value.c_str(),path.c_str());}WritePrivateProfileStringW(L"layout",L"hit",esp_layout_runtime::show_hit?L"1":L"0",path.c_str());}
 else {for(int i=0;i<flag_count;i++){const auto key=L"flag"+std::to_wstring(i);const unsigned value=GetPrivateProfileIntW(L"layout",key.c_str(),0,path.c_str());placements[i]=(value&~0x8003ffffu)?0:value;}esp_layout_runtime::show_hit=GetPrivateProfileIntW(L"layout",L"hit",0,path.c_str())==1;}
}
inline BOOL CALLBACK choose_window(HWND hwnd,LPARAM){wchar_t name[64]{};DWORD pid=0;GetWindowThreadProcessId(hwnd,&pid);if(pid==GetCurrentProcessId()&&IsWindowVisible(hwnd)&&GetClassNameW(hwnd,name,64)&&!std::wcscmp(name,L"Valve001")){ui_preview_input::attach(hwnd);return FALSE;}return TRUE;}
inline void cancel(){if(drag>=0)placements[drag]=drag_before;drag=-1;color_drag=-1;color_item=-1;settings_open=false;ui_preview_input::modal=false;agent_preview::pause();}
inline void prepare(CMenu* m,IRenderer* live=nullptr,bool poll_input=true){
 if(live&&esp_layout_runtime::supported_renderer(live))draw_renderer=live;
 if(!draw_renderer&&ready(m)&&esp_layout_runtime::supported_renderer(context->IRenderer))draw_renderer=context->IRenderer;
 if(!loaded&&ready(m)&&esp_layout_runtime::supported_renderer(draw_renderer)){persistence(false);loaded=true;}
 shown=ready(m)&&esp_layout_runtime::supported_renderer(draw_renderer)&&attached&&(m->MenuStatus&MenuOpened)&&m->CurrentTab==VISUALS&&active==Enemy;
 if(!shown){cancel();ui_preview_input::publish(0,0,0,0,false);return;}
 if(!ui_preview_input::window){static unsigned retry=0;const unsigned now=GetTickCount();if(!retry||now-retry>=2000){retry=now;EnumWindows(&choose_window,0);}}
 int w=0,h=0;draw_renderer->ScreenSize(&w,&h);if(w<320||h<200){RECT client{};if(ui_preview_input::window&&GetClientRect(ui_preview_input::window,&client)){w=client.right;h=client.bottom;}else{w=GetSystemMetrics(SM_CXSCREEN);h=GetSystemMetrics(SM_CYSCREEN);}}
 plan=preview({m->Pos.x,m->Pos.y,m->Size.x,m->Size.y},w,h,scale());
 // Native picker uses +0xa1 as its popup-open flag (also read by its draw and hit test).
 bool picker_open=false;
 for(unsigned i=0;i<binding_count;i++){auto* b=bindings[i].proxy?bindings[i].proxy->GetAs<Checkbox>():nullptr;
  if(b&&b->Header.Flags.Visible&&b->Header.Type==UiColorPicker&&*(reinterpret_cast<unsigned char*>(b)+0xa1)){picker_open=true;break;}}
 ui_preview_input::publish(plan.area.x,plan.area.y,plan.area.w,plan.area.h,!picker_open);
 if(poll_input){input.tick();if(input.cancelled)cancel();flag_sources();}
}
inline agent_preview::Style style(){
 agent_preview::Style result{};if(!checked(L"Player",EnemyModels)){if(checked(L"Glow",EnemyModels)){result.material=agent_preview::Material::Glow;result.rgba=tint(L"Glow",EnemyModels,0xffbbbbaa);}return result;}
 result.material=agent_preview::Material::Shaded;result.rgba=tint(L"Player",EnemyModels,0xffbbbbaau);
 for(unsigned i=0;i<binding_count;i++){auto& b=bindings[i];if(b.group->panel==EnemyModels&&eq(b.anchor,L"Player")&&b.source->GetAs<Checkbox>()->Header.Type==UiCombobox){auto* m=b.source->GetAs<Combobox>();if(m->Value&&m->Vars.size()<=128)for(auto& v:m->Vars)if(v.Index==*m->Value){wchar_t name[64]{};unsigned j=0;for(auto c:v.Name){if(!c||j>=63)break;name[j++]=c;}if(has(name,L"Solid")||has(name,L"Flat"))result.material=agent_preview::Material::Solid;else if(has(name,L"Glow"))result.material=agent_preview::Material::Glow;}}}
 return result;
}
inline Rect box_in(Rect target){const auto* b=agent_preview::player.bounds;return {target.x+int(b[0]*target.w),target.y+int(b[1]*target.h),std::max(4,int(b[2]*target.w)),std::max(8,int(b[3]*target.h))};}
inline void draw_image(IRenderer* r,Rect image){r->Texture(agent_preview::texture_id,image.x,image.y,0xffffffff,0,0,image.w,image.h,1,1.f);}
inline void paint(){
 if(!shown||!attached)return;auto* r=draw_renderer;menu_paint::Paint p{r,plan.scale};
RendererOverlayScope overlay(r);r->SetZBuff(0.2f);
 const auto a=plan.area;const auto accent=menu_paint::accent();p.fill(a,0xff111111);p.border(a,0xff555555);p.border({a.x+2,a.y+2,a.w-4,a.h-4},0xff292929);
 const unsigned rainbow[]={0xffceb94d,0xffbc76b8,0xff5b99cd,0xff8db7a0};for(int i=0;i<3;i++)r->GradientH(a.x+3+(a.w-6)*i/3,a.y+3,(a.w-6)/3+1,1,rainbow[i],rainbow[i+1]);
 p.text(a.x+p.s(12),a.y+p.s(13),L"Enemy ESP preview",0xffdddddd,std::max(50,a.w-p.s(100)));p.gear(plan.gear,settings_open?accent:0xffaaaaaa);p.border(plan.reset,0xff333333);p.text(plan.reset.x+p.s(5),plan.reset.y+p.s(3),L"Reset",0xffaaaaaa,plan.reset.w);
 const float image_scale=std::min(float(plan.model.w)/agent_preview::texture_width,float(plan.model.h)/agent_preview::texture_height);
 const Rect image{plan.model.x+(plan.model.w-int(agent_preview::texture_width*image_scale))/2,plan.model.y,int(agent_preview::texture_width*image_scale),int(agent_preview::texture_height*image_scale)};
 const bool scene_ready=agent_preview::render(GetTickCount(),0,style());const bool rendered=scene_ready&&agent_preview::gpu_texture(r);
 if(rendered)draw_image(r,image);
 else {if(scene_ready)agent_preview::diagnostic=L"Preview: GPU texture unavailable";p.text(plan.model.x,plan.model.y+p.s(90),agent_preview::diagnostic,0xffaaaaaa,plan.model.w);p.text(plan.model.x,plan.model.y+p.s(110),L"Requires CS:GO Legacy 8802 assets",0xff777777,plan.model.w);}
 const auto box=box_in(image);
 if(rendered){
  if(checked(L"Bounding box")){p.border({box.x-1,box.y-1,box.w+2,box.h+2},0xff000000);p.border(box,tint(L"Bounding box",EnemyESP,0xffeeeeee));}
  if(checked(L"Health bar")){p.fill({box.x-p.s(6),box.y, p.s(3),box.h},0xff050505);p.fill({box.x-p.s(5),box.y+box.h/4,p.s(1),box.h*3/4},accent);p.text(box.x-p.s(11),box.y+box.h/4-p.s(8),L"75",0xffeeeeee,40);}
  if(checked(L"Name"))p.text(box.x+box.w/2-p.s(14),box.y-p.s(14),L"Player",tint(L"Name",EnemyESP,0xffeeeeee),80);
  if(checked(L"Skeleton")){const auto& player=agent_preview::player;for(unsigned i=0;i<player.joint_count;i++){const auto& j=player.joints[i];if(!j.used||!j.valid||j.parent<0||unsigned(j.parent)>=player.joint_count)continue;const auto& parent=player.joints[j.parent];if(parent.valid)r->Line(image.x+int(j.x*image.w),image.y+int(j.y*image.h),image.x+int(parent.x*image.w),image.y+int(parent.y*image.h),tint(L"Skeleton",EnemyESP,0xffeeeeee));}}
  if(checked(L"Ammo")){p.fill({box.x,box.y+box.h+p.s(4),box.w,p.s(3)},0xff050505);p.fill({box.x,box.y+box.h+p.s(5),box.w*3/4,p.s(1)},tint(L"Ammo",EnemyESP,0xffd78c46));}
  if(checked(L"Weapon text")||checked(L"Weapon icon"))p.text(box.x+box.w/2-p.s(10),box.y+box.h+p.s(10),L"AWP",0xffdddddd,100);
  if(checked(L"Distance"))p.text(box.x+box.w/2-p.s(6),box.y+box.h+p.s(22),L"20m",0xffaaaaaa,100);
 }
 for(auto& b:labels)b={};int rank=0;
 if(rendered)for(int i=0;i<flag_count;i++)if(enabled_flags[i]){int text[2]{};r->MeasureText(text,samples[i],std::wcslen(samples[i]),0);auto at=placed(box,text[0],text[1],Placement::unpack(placements[i]),rank++,plan.scale);labels[i]=at;if(drag==i){p.border({at.x-2,at.y-2,at.w+4,at.h+4},accent);}p.text(at.x,at.y,samples[i],flag_colors[i]);}
 const bool was_open=settings_open;
 if(input.press&&!settings_open){const int x=input.press_x,y=input.press_y;if(inside(plan.gear,x,y)){settings_open=true;scroll=0;}else if(inside(plan.reset,x,y)){for(auto& value:placements)value=0;persistence(true);}else if(rendered)for(int i=0;i<flag_count;i++)if(enabled_flags[i]&&inside(labels[i],x,y)){drag=i;drag_before=placements[i];break;}}
 if(drag>=0&&rendered){if(ui_preview_input::held)placements[drag]=dropped(box,input.x,input.y).pack();if(input.release){placements[drag]=dropped(box,input.x,input.y).pack();drag=-1;persistence(true);}p.border(box,menu_interaction::opacity(accent,.5f));}
 if(settings_open){
  Rect popup{a.x+p.s(8),a.y+p.s(44),a.w-p.s(16),a.h-p.s(56)};p.fill(popup,0xff151515);p.border(popup,0xff555555);p.text(popup.x+p.s(10),popup.y+p.s(10),L"Manage elements",0xffdddddd,popup.w-p.s(25));
  if(was_open&&input.press&&inside(plan.gear,input.press_x,input.press_y))settings_open=false;
  const int rowh=p.s(22),start=popup.y+p.s(34),capacity=std::max(1,(popup.h-p.s(48))/rowh);int row=0,total=0;
  for(const auto* name:basic_names)if(find(name,UiCheckbox))total++;
  if(color_item>=0&&color_item<int(std::size(basic_names))&&color_source(basic_names[color_item]))total+=4;
  for(int i=0;i<flag_count;i++)if(flags[i].binding||i==10)total++;
  const int wheel=ui_preview_input::wheel.exchange(0);if(wheel)scroll-=wheel/120;scroll=std::clamp(scroll,0,std::max(0,total-capacity));
  const auto option=[&](const wchar_t* name,bool value,Binding* binding,int id,int basic=-1){const int index=row++;if(index<scroll||index>=scroll+capacity)return;Rect line{popup.x+p.s(8),start+(index-scroll)*rowh,popup.w-p.s(16),rowh};
   p.fill({line.x+p.s(2),line.y+p.s(5),p.s(6),p.s(6)},value?accent:0xff444444);p.text(line.x+p.s(18),line.y+p.s(3),name,0xffbbbbbb,line.w-p.s(48));
   Rect swatch{line.x+line.w-p.s(22),line.y+p.s(5),p.s(17),p.s(9)};const bool picker=basic>=0&&color_source(name);if(picker){p.fill(swatch,tint(name,EnemyESP,0xffffffff));p.border(swatch,0xff777777);}
   if(input.press&&inside(line,input.press_x,input.press_y)){if(picker&&inside(swatch,input.press_x,input.press_y)){color_item=color_item==basic?-1:basic;color_drag=-1;}else if(id>=0){toggle_flag(id);if(id==10)persistence(true);}else toggle(binding);}};
  for(unsigned basic=0;basic<std::size(basic_names);basic++){const auto* name=basic_names[basic];if(auto* b=find(name,UiCheckbox))option(name,checked(name),b,-1,int(basic));
   if(color_item!=int(basic)||!color_source(name))continue;
   for(int channel=0;channel<4;channel++){const int index=row++;if(index<scroll||index>=scroll+capacity)continue;
    Rect bar{popup.x+p.s(38),start+(index-scroll)*rowh+p.s(5),popup.w-p.s(54),p.s(10)};
    unsigned color=tint(name,EnemyESP,0xffffffff),value=(color>>(channel*8))&255;wchar_t caption[16]{};std::swprintf(caption,16,L"%lc %u",L"RGBA"[channel],value);
    p.text(popup.x+p.s(10),bar.y,caption,0xffbbbbbb,p.s(30));p.fill(bar,0xff333333);p.fill({bar.x,bar.y,bar.w*int(value)/255,bar.h},channel==3?0xffbbbbbb:0xff000000u|(255u<<(channel*8)));
    if(input.press&&inside({bar.x,bar.y-p.s(4),bar.w,bar.h+p.s(8)},input.press_x,input.press_y))color_drag=channel;
    if(color_drag==channel&&ui_preview_input::held){const unsigned next=unsigned(std::clamp(float(input.x-bar.x)/std::max(1,bar.w),0.f,1.f)*255.f+.5f);const unsigned mask=255u<<(channel*8);set_color(name,(color&~mask)|(next<<(channel*8)));}
   }
  }
  if(input.release)color_drag=-1;
  for(int i=0;i<flag_count;i++)if(flags[i].binding||i==10)option(flag_names[i],enabled_flags[i],nullptr,i);
  if(total>capacity)p.text(popup.x+p.s(10),popup.y+popup.h-p.s(15),L"Scroll for more",0xff777777,popup.w-p.s(15));
 }
 ui_preview_input::modal=settings_open||drag>=0;

}
}
