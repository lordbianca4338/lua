#pragma once
#include "cs2_visuals_design.h"
namespace skin_menu_design {
using cs2_visuals::Rect;
enum Panel {Models,Weapon,Settings,Count};
inline constexpr const wchar_t* titles[]={L"Model customization",L"Weapon skin",L"Settings"};
inline std::array<Rect,Count> layout(int width,int height,float dpi) {
    const auto s=[&](int n){return std::max(1,int(n*dpi+.5f));};
    const int left=s(100),top=s(20),right=s(25),gap=s(22),bottom=s(20);
    const int full=std::max(s(240),width-left-right),col=(full-gap)/2;
    const int h=std::max(s(180),height-top-bottom),settings=s(70),v_gap=s(12);
    return {{{left,top,col,h-settings-v_gap},{left+col+gap,top,full-col-gap,h},
             {left,top+h-settings,col,settings}}};
}
inline int route(const wchar_t* group,const wchar_t* name,unsigned source_index) {
    using namespace cs2_visuals;
    if(eq(name,L"Filter by weapon"))return Settings;
    if(has(group,L"Weapon")||has(group,L"weapon"))return Weapon;
    if(has(group,L"Model")||has(group,L"model"))return Models;
    if(has(group,L"Settings"))return Settings;
    return source_index?Weapon:Models;
}
inline bool agent(const wchar_t* name) {
    using namespace cs2_visuals;
    return has(name,L"Player model")||has(name,L"player model")||has(name,L"Agent")||has(name,L"agent");
}
inline const wchar_t* collection(const wchar_t* name) {
    using namespace cs2_visuals;
    if(has(name,L"Little Kev")||has(name,L"Getaway Sally")||has(name,L"Number K")||
       has(name,L"Darryl")||has(name,L"Voltzmann"))return L"The Professionals";
    return nullptr;
}
}
