#pragma once
#include "skin_native_client.h"
#include "local_client_interfaces.h"
#include <cwchar>
namespace agent_inventory_client {
using namespace local_inventory_client;
// Schema indexing is deliberately incremental. Neither menu callbacks nor a
// configuration load may synchronously enumerate the entire item schema.
inline constexpr unsigned rows_per_frame=64,max_agents=256;
struct Agent {int id=0;wchar_t name[256]{};};
struct Stats {unsigned examined=0,steps=0,max_step_rows=0,resets=0;};
struct Index {
 void* schema=nullptr;unsigned char* nodes=nullptr;unsigned count=0,cursor=0,used=0;
 bool complete=false,overflow=false;Agent agents[max_agents]{};Stats stats{};
 void reset(void* s,void* n,unsigned size) {
  const unsigned resets=stats.resets+1;schema=s;nodes=static_cast<unsigned char*>(n);count=size;cursor=used=0;complete=overflow=false;stats={};stats.resets=resets;
  // Entries beyond used are inaccessible. Avoid a 128 KiB temporary/clear on
  // the render stack when the inventory or schema changes.
 }
 bool prepare(void* s) {
  if(!memory(s,0xe8))return false;auto* n=pointer(s,0xd0);const auto size=read32(s,0xe4);
  if(!size||size>65536||!memory(n,std::size_t(size)*12))return false;
  if(s!=schema||n!=nodes||size!=count)reset(s,n,size);return true;
 }
 static bool text(const wchar_t* from,wchar_t (&to)[256]) {
  if(!from)return false;MEMORY_BASIC_INFORMATION m{};
  if(!VirtualQuery(from,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
  const auto at=reinterpret_cast<std::uintptr_t>(from),first=reinterpret_cast<std::uintptr_t>(m.BaseAddress);
  if(at<first||at-first>=m.RegionSize)return false;
  const auto available=(m.RegionSize-(at-first))/2;const auto limit=(std::min)(std::size_t(256),std::size_t(available));
  for(unsigned i=0;i<limit;i++){to[i]=from[i];if(!to[i])return true;}to[0]=0;return false;
 }
 void step() {
  if(!schema||complete)return;
  if(!prepare(schema)){schema=nullptr;return;}
  auto* loc=local_client_interfaces::core_interface(0x4346a31c);auto* find=local_client_interfaces::method(loc,11);
  // Missing localization should retry later, not create a permanently empty index.
  if(!find)return;
  using Find=const wchar_t*(__thiscall*)(void*,const char*);using Name=const char*(__thiscall*)(void*);
  LARGE_INTEGER frequency{},start{},now{};const bool timed=QueryPerformanceFrequency(&frequency)&&frequency.QuadPart>0&&QueryPerformanceCounter(&start);
  unsigned processed=0;
  while(cursor<count&&processed<rows_per_frame) {
   auto* row=nodes+cursor++*12;++processed;++stats.examined;
   auto* def=pointer(row,4);
   if(int(read32(row,8))>=-1&&memory(def,0x2a0)) {
    // The supplied client's native slot getter uses exactly these fields.
    const bool agent=read32(def,0x268)==38||read32(def,0x294)==38||read32(def,0x298)==38;
    const unsigned id=*reinterpret_cast<const unsigned short*>(static_cast<unsigned char*>(def)+8);
    if(agent&&id) {
     auto* getter=method(def,2);const auto* token=getter?reinterpret_cast<Name>(getter)(def):nullptr;
     bool terminated=false;if(memory(token,1)) {
      MEMORY_BASIC_INFORMATION m{};if(VirtualQuery(token,&m,sizeof(m))){const auto offset=reinterpret_cast<std::uintptr_t>(token)-reinterpret_cast<std::uintptr_t>(m.BaseAddress);const auto limit=(std::min)(std::size_t(256),std::size_t(m.RegionSize-offset));for(unsigned c=0;c<limit;c++)if(!token[c]){terminated=true;break;}}
     }
     wchar_t name[256]{};
     if(terminated)text(reinterpret_cast<Find>(find)(loc,token),name);
     {
      bool duplicate=false;for(unsigned n=0;n<used;n++)if(agents[n].id==int(id)){duplicate=true;break;}
      if(!duplicate){if(used==max_agents)overflow=true;else {auto& a=agents[used++];a.id=int(id);std::memcpy(a.name,name,sizeof(name));}}
     }
    }
   }
   // 0.75 ms soft budget in addition to the hard 64-node bound. A single
   // external localization call is outside our timing guarantee.
   if(timed&&QueryPerformanceCounter(&now)&&now.QuadPart-start.QuadPart>=frequency.QuadPart*3/4000)break;
  }
  ++stats.steps;stats.max_step_rows=(std::max)(stats.max_step_rows,processed);complete=cursor==count;
 }
 int lookup(int value,const wchar_t* name)const {
  for(unsigned i=0;i<used;i++)if(agents[i].id==value)return value;
  if(!complete||overflow||!name||!name[0])return 0;int found=0;
  for(unsigned i=0;i<used;i++)if(!std::wcscmp(agents[i].name,name)){if(found&&found!=agents[i].id)return 0;found=agents[i].id;}
  return found;
 }
};
inline Index index{};inline bool requested=false;
inline bool label(void* tab,unsigned side,int value,wchar_t (&out)[256]) {
 if(side>1||!memory(tab,0x118))return false;auto* combo=pointer(tab,0x110+side*4);
 if(!memory(combo,0x88)||*(static_cast<unsigned char*>(combo)+0x19)!=4)return false;
 auto* rows=static_cast<unsigned char*>(pointer(combo,0x7c));const auto end=read32(combo,0x80),begin=reinterpret_cast<std::uintptr_t>(rows);
 if(end<begin||(end-begin)%20||(end-begin)/20>512||!memory(rows,end-begin))return false;
 for(unsigned i=0;i<(end-begin)/20;i++) {
  auto* row=rows+i*20;if(int(read32(row,16))!=value)continue;
  auto* text=static_cast<wchar_t*>(pointer(row,0));const auto last=read32(row,4),first=reinterpret_cast<std::uintptr_t>(text);
  if(last<first||(last-first)%2||(last-first)/2>256||!memory(text,last-first))return false;
  unsigned n=0;while(n<(last-first)/2&&text[n]){out[n]=text[n];++n;}if(n==256)return false;out[n]=0;
  unsigned skip=out[0]==7&&n>=9?9:0;while(skip<n&&(out[skip]==L' '||out[skip]==L'\t'))++skip;
  if(skip){std::memmove(out,out+skip,(n-skip+1)*2);n-=skip;}
  while(n&&(out[n-1]==L' '||out[n-1]==L'\t'))out[--n]=0;return n>0;
 }
 return false;
}
inline void step() {if(requested)index.step();}
inline unsigned normalize(void* tab,skin_native_state::Raw& raw) {
 requested=raw.agent_on[0]||raw.agent_on[1];if(!requested)return 0;
 if(!ready())return 0;auto* sch=schema();const bool prepared=index.prepare(sch);unsigned pending=0;
 for(unsigned side=0;side<2;side++)if(raw.agent_on[side]&&raw.agent_model[side]>0) {
  wchar_t name[256]{};label(tab,side,raw.agent_model[side],name);
  const int id=prepared?index.lookup(raw.agent_model[side],name):0;
  if(id)raw.agent_model[side]=id;
  else {raw.agent_on[side]=false;if(!prepared||!index.complete)pending|=1u<<(side+2);}
 }
 return pending;
}
inline void reset(){index.reset(nullptr,nullptr,0);index.stats={};requested=false;}
}
