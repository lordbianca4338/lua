#pragma once
// Native IElement::HandleDPI scales +0x30/+0x34 into +0x28/+0x2c.
// Keep the canonical dimensions distinct from already scaled pixel geometry.
namespace native_layout_state {
inline int canonical(int pixels,float dpi) {return std::max(1,int(pixels/dpi+.5f));}
template<class T> inline void size(T* object,int width,int height,float dpi) {
    object->Size={width,height};
    const int base[]={canonical(width,dpi),canonical(height,dpi)};
    std::memcpy(reinterpret_cast<char*>(object)+0x30,base,sizeof(base));
}
template<class T> inline void fixed(T* child,int x,int y,int w,int h,float dpi) {
    child->Pos={x,y};size(child,w,h,dpi);
    child->Widgets.Modifiable=false;child->Widgets.Movable=false;
}
struct Epoch {
    int w=0,h=0;float dpi=0;
    // 1=resize, 2=DPI or first layout. Reading does not consume the change.
    int change(int width,int height,float scale) const {return dpi!=scale?2:(w!=width||h!=height?1:0);}
    void commit(int width,int height,float scale){w=width;h=height;dpi=scale;}
};
}
