#pragma once
#include <cstdint>
#include <cstring>
#ifdef _WIN32
#define PROXY_THISCALL __thiscall
#else
#define PROXY_THISCALL
#endif
namespace native_ui_proxy {
using Allocate=void*(PROXY_THISCALL*)(int);
using Destroy=void(*)(void*);
using Check=void*(PROXY_THISCALL*)(void*,void*,const wchar_t*,int*);
using Slider=void*(PROXY_THISCALL*)(void*,void*,const wchar_t*,int,int,int*,bool,unsigned,float);
using Combo=void*(PROXY_THISCALL*)(void*,void*,const wchar_t*,int*,bool);
using Multi=void*(PROXY_THISCALL*)(void*,void*,const wchar_t*,int*,int,bool);
using Picker=void*(PROXY_THISCALL*)(void*,void*,void*);
using Hotkey=void*(PROXY_THISCALL*)(void*,void*,void*,bool);
using Label=void*(PROXY_THISCALL*)(void*,void*,const wchar_t*);
using Insert=void(PROXY_THISCALL*)(void*,bool,void*);
using Copy=bool(*)(void*,void*,int);
using Link=void(*)(void*,void*);
struct Api {Allocate allocate;Destroy destroy;Check check;Slider slider;Combo combo;Multi multi;Picker picker;Hotkey hotkey;Label label;Insert insert;Copy copy;Link link;};
inline int number(const void* source,unsigned offset){int value;std::memcpy(&value,static_cast<const char*>(source)+offset,4);return value;}
inline void* pointer(const void* source,unsigned offset){return reinterpret_cast<void*>(std::uintptr_t(std::uint32_t(number(source,offset))));}
inline bool supported(int type){return type==3||type==4||type==5||type==8||type==9||type==12||type==13;}
// A fresh native object owns its name, popup and vectors. Only the model pointer
// is shared. No memcpy of a polymorphic native object or shared_ptr is used.
inline void* create(const Api& api,void* parent,void* source,const wchar_t* name) {
    if(!parent||!source||!name)return nullptr;
    const auto* bytes=static_cast<const unsigned char*>(source);const int type=bytes[0x19];
    if(!supported(type))return nullptr;
    const int sizes[]={0,0,0,0x78,0xa8,0x124,0,0,0x60,0x70,0,0,0x138,0x32c};
    void* value=pointer(source,0x5c);if(type!=8&&!value)return nullptr;
    unsigned char saved[8]{};unsigned length=type==8?0:(type==9?8:(type==3?1:4));
    auto* model=value?static_cast<unsigned char*>(value)+(type==9?16:0):nullptr;
    if(length)std::memcpy(saved,model,length);
    void* out=api.allocate(sizes[type]);if(!out)return nullptr;
    const bool same=bytes[0x18]!=0;
    switch(type) {
    case 3:api.check(out,parent,name,static_cast<int*>(value));break;
    case 4:api.combo(out,parent,name,static_cast<int*>(value),same);break;
    case 5: {
        float step;std::memcpy(&step,bytes+0x98,4);
        api.slider(out,parent,name,number(source,0x94),number(source,0x90),static_cast<int*>(value),bytes[0x69]!=0,static_cast<unsigned>(number(source,0xa0)),step);break;
    }
    case 8:api.label(out,parent,name);break;
    case 9:api.hotkey(out,parent,value,true);break;
    case 12:api.picker(out,parent,value);break;
    case 13:api.multi(out,parent,name,static_cast<int*>(value),0,bytes[0x6a]!=0);break;
    }
    if(length)std::memcpy(model,saved,length);
    try {
        if(!api.copy(out,source,type)){api.destroy(out);return nullptr;}
        // Preserve native indentation, font, initial visibility and SameLine.
        auto* target=static_cast<unsigned char*>(out);
        std::memcpy(target+0x14,bytes+0x14,5);std::memcpy(target+0x1c,bytes+0x1c,4);
        if(type!=4)std::memcpy(target+0x54,bytes+0x54,4);
        api.link(out,source);
    } catch(...) {api.destroy(out);throw;}
    api.insert(parent,false,out);return out;
}
}
#undef PROXY_THISCALL
