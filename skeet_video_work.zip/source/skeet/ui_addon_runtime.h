#pragma once
#include <windows.h>
#include <array>
#include <atomic>
#include <cstring>
#include <cmath>
#include "sticker_state.h"
#include "ui_addon_embedded.h"
extern "C" {
__declspec(dllexport) void clover_ui_heartbeat(void);
__declspec(dllexport) void clover_ui_module(unsigned int);
__declspec(dllexport) void clover_night(int,unsigned int,unsigned int,unsigned int);
__declspec(dllexport) void clover_night_reset(void);
__declspec(dllexport) int clover_telemetry(void*,unsigned int);
__declspec(dllexport) int clover_selected_weapon(void);
__declspec(dllexport) int clover_sticker_set(int,unsigned int,int,float,float,float);
__declspec(dllexport) int clover_sticker_get(int,unsigned int,void*);
__declspec(dllexport) int clover_sky(const char*);
__declspec(dllexport) int clover_sky_tint(const char*,unsigned int);
}
namespace ui_addon {
inline std::atomic<unsigned> modules{0};
inline bool attempted=false,loaded=false;inline unsigned start=0;inline std::atomic<unsigned> heartbeat_at{0},heartbeat_gap{0};
inline void heartbeat(){heartbeat_at.store(GetTickCount());heartbeat_gap.store(0);}inline unsigned char* engine=nullptr;
inline unsigned long long ft(FILETIME t){return (static_cast<unsigned long long>(t.dwHighDateTime)<<32)|t.dwLowDateTime;}
struct Telemetry {unsigned size=sizeof(Telemetry),valid=0;float cpu_percent=0,cpu_ghz=0;float ram_used_gib=0,ram_total_gib=0,process_mib=0;};
inline Telemetry telemetry{};inline unsigned sample_at=0;inline bool sampled=false;inline unsigned long long previous_idle=0,previous_total=0;
inline void sample(unsigned now){if(sampled&&now-sample_at<1000)return;sample_at=now;sampled=true;
 MEMORYSTATUSEX mem{};mem.dwLength=sizeof(mem);if(GlobalMemoryStatusEx(&mem)){telemetry.ram_total_gib=float(double(mem.ullTotalPhys)/1073741824.);telemetry.ram_used_gib=float(double(mem.ullTotalPhys-mem.ullAvailPhys)/1073741824.);telemetry.valid|=4;}
 FILETIME idle{},kernel{},user{};if(GetSystemTimes(&idle,&kernel,&user)){const auto id=ft(idle),total=ft(kernel)+ft(user);if(previous_total&&total>previous_total&&id>=previous_idle){const auto delta=total-previous_total;telemetry.cpu_percent=std::clamp(float(double(delta-std::min(delta,id-previous_idle))*100./delta),0.f,100.f);telemetry.valid|=1;}previous_idle=id;previous_total=total;}
 PROCESS_MEMORY_COUNTERS proc{};proc.cb=sizeof(proc);if(GetProcessMemoryInfo(GetCurrentProcess(),&proc,sizeof(proc))){telemetry.process_mib=float(double(proc.WorkingSetSize)/1048576.);telemetry.valid|=8;}
 // Windows-reported current MHz. Missing firmware data remains unavailable.
 struct Power {ULONG number,max_mhz,current_mhz,limit_mhz,max_idle,current_idle;};
 using Query=LONG(WINAPI*)(int,void*,ULONG,void*,ULONG);
 static HMODULE power=LoadLibraryW(L"powrprof.dll");static auto query=power?reinterpret_cast<Query>(GetProcAddress(power,"CallNtPowerInformation")):nullptr;
 if(query){SYSTEM_INFO info{};GetSystemInfo(&info);if(info.dwNumberOfProcessors&&info.dwNumberOfProcessors<=256){std::array<Power,256> values{};if(query(11,nullptr,0,values.data(),info.dwNumberOfProcessors*sizeof(Power))==0){double sum=0;unsigned n=0;for(unsigned i=0;i<info.dwNumberOfProcessors;i++)if(values[i].current_mhz&&values[i].current_mhz<=20000){sum+=values[i].current_mhz;++n;}if(n){telemetry.cpu_ghz=float(sum/n/1000.);telemetry.valid|=2;}}}}
}
inline bool sky_name(const char* p){if(!p||!*p)return false;unsigned n=0;for(;p[n]&&n<96;n++){const unsigned char c=p[n];if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='/'))return false;}return n>0&&n<96;}
inline bool sky(const char* name){if(!sky_name(name))return false;auto* mod=reinterpret_cast<unsigned char*>(GetModuleHandleW(L"engine.dll"));if(!mod)return false;
 auto* nt=reinterpret_cast<IMAGE_NT_HEADERS32*>(mod+*reinterpret_cast<unsigned*>(mod+0x3c));
 constexpr unsigned char code[]={0x55,0x8b,0xec,0x81,0xec,0x34,1,0,0,0x56,0x57,0x8b,0xf9};
 if(nt->Signature!=IMAGE_NT_SIGNATURE||nt->FileHeader.TimeDateStamp!=0x64ee7e86||nt->OptionalHeader.SizeOfImage!=0x39c0000||std::memcmp(mod+0x137780,code,sizeof(code)))return false;
 // Native LoadNamedSky(name in ECX). Its own material error check retains the
 // current sky when a file is missing; this does not load CS2 .vmap resources.
 if(!*reinterpret_cast<void**>(mod+0x3926e38))return false;
 using Load=bool(__fastcall*)(const char*,void*);return reinterpret_cast<Load>(mod+0x137780)(name,nullptr);
}
struct SkyTint {void* material=nullptr;float old[3]{};};inline std::array<SkyTint,6> sky_materials{};inline char tinted_name[96]{};inline unsigned tinted_color=0;
inline bool tint_method(void* material,unsigned slot){if(!material||!agent_preview::module(agent_preview::materials))return false;return agent_preview::method(material,slot,agent_preview::materials)!=nullptr;}
inline void restore_tint(){for(auto& saved:sky_materials)if(saved.material){if(tint_method(saved.material,28))agent_preview::call<void>(saved.material,28,saved.old[0],saved.old[1],saved.old[2]);if(tint_method(saved.material,13))agent_preview::call<void>(saved.material,13);saved={};}tinted_name[0]=0;tinted_color=0;}
inline bool sky_tint(const char* name,unsigned color){
 if(!name){restore_tint();return true;}if(!sky_name(name))return false;
 if(!std::strcmp(name,tinted_name)&&color==tinted_color)return true;
 if(std::strcmp(name,tinted_name)){restore_tint();if(!agent_preview::module(agent_preview::materials))return false;auto* system=agent_preview::factory(agent_preview::materials,"VMaterialSystem080");if(!system||!agent_preview::method(system,84,agent_preview::materials))return false;
  constexpr const char* suffix[]={"rt","lf","bk","ft","up","dn"};unsigned accepted=0;
  for(unsigned i=0;i<6;i++){char path[128]{};std::snprintf(path,sizeof(path),"skybox/%s%s",name,suffix[i]);auto* material=agent_preview::call<void*>(system,84,static_cast<const char*>(path),"SkyBox textures",false,static_cast<const char*>(nullptr));
   if(!tint_method(material,12)||!tint_method(material,13)||!tint_method(material,28)||!tint_method(material,42)||!tint_method(material,45)||agent_preview::call<bool>(material,42))continue;
   auto& saved=sky_materials[i];saved.material=material;agent_preview::call<void>(material,12);agent_preview::call<void>(material,45,&saved.old[0],&saved.old[1],&saved.old[2]);++accepted;}
  if(!accepted)return false;std::strcpy(tinted_name,name);
 }
 const float r=float(color&255)/255,g=float((color>>8)&255)/255,b=float((color>>16)&255)/255;
 for(auto& saved:sky_materials)if(saved.material&&tint_method(saved.material,28))agent_preview::call<void>(saved.material,28,r,g,b);tinted_color=color;return true;
}
inline const char* bound_script(){return ui_addon_script;}
inline void bootstrap(SkeetSDK::CMenu* cs2_bootstrap_menu){
 if(attempted)return;
 if(!start){start=GetTickCount();return;}if(GetTickCount()-start<1500)return;
 auto* load=reinterpret_cast<unsigned char*>(0x43419b27u);MEMORY_BASIC_INFORMATION memory{};
 if(!VirtualQuery(load,&memory,sizeof(memory))||memory.State!=MEM_COMMIT)return;
 constexpr unsigned char signature[]={0x83,0xec,0x4c,0x53,0x55,0x33,0xc0};if(std::memcmp(load,signature,sizeof(signature)))return;
 attempted=true;wchar_t path[MAX_PATH]{};const DWORD n=GetCurrentDirectoryW(MAX_PATH,path);if(!n||n>=MAX_PATH-40)return;
 const wchar_t* filename=L"clover_cs2_ui_8802.lua";std::wcscat(path,L"\\");std::wcscat(path,filename);
 auto file=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(file==INVALID_HANDLE_VALUE)return;
 const char* script=bound_script();DWORD wrote=0;const DWORD size=sizeof(ui_addon_script)-1;const bool ok=WriteFile(file,script,size,&wrote,nullptr)&&wrote==size;CloseHandle(file);if(!ok)return;
 modules.store(0);using Load=bool(__thiscall*)(const wchar_t*);loaded=reinterpret_cast<Load>(load)(L"clover_cs2_ui_8802");
 if(!loaded)OutputDebugStringA("Clover: bundled World/Misc/sticker UI failed to load; see Lua errors.");
}
}
extern "C" {
__declspec(dllexport) void clover_ui_module(unsigned mask){ui_addon::modules.fetch_or(mask&15u);}
__declspec(dllexport) void clover_ui_heartbeat(){ui_addon::heartbeat();}
__declspec(dllexport) int clover_telemetry(void* out,unsigned size){if(!out||size!=sizeof(ui_addon::Telemetry))return 0;ui_addon::sample(GetTickCount());std::memcpy(out,&ui_addon::telemetry,size);return 1;}
__declspec(dllexport) int clover_sticker_set(int weapon,unsigned slot,int id,float wear,float scale,float rotation){return sticker_state::set(weapon,slot,{id,wear,scale,rotation});}
__declspec(dllexport) int clover_sticker_get(int weapon,unsigned slot,void* out){if(!out||!sticker_state::gun(weapon)||slot>=4)return 0;std::memcpy(out,&sticker_state::weapons[weapon].slots[slot],sizeof(sticker_state::Sticker));return 1;}
__declspec(dllexport) int clover_sky(const char* name){return ui_addon::sky(name);}
__declspec(dllexport) int clover_sky_tint(const char* name,unsigned color){return ui_addon::sky_tint(name,color);}
}

#include "ui_addon_mailbox.h"
