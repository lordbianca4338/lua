#pragma once
#include "menu_interaction_design.h"
#include "local_client_interfaces.h"
#include "renderer_overlay_scope.h"
namespace esp_layout_runtime {
using namespace menu_interaction;using local_inventory_client::memory;using local_inventory_client::pointer;using local_inventory_client::read32;
inline bool menu_drawing=false;
inline std::atomic<bool> show_hit{false};
inline unsigned hit_until[65]{},actor[64]{},last_bottom[64]{};
inline bool events_bound=false;
inline unsigned event_retry=0;
inline void __fastcall event_received(void*,void*,void* event){
 if(!show_hit||!event)return;auto* engine=local_client_interfaces::core_interface(0x4346a514);
 auto* get=local_client_interfaces::method(event,6);auto* user=local_client_interfaces::method(engine,9);auto* local=local_client_interfaces::method(engine,12);if(!get||!user||!local)return;
 using Int=int(__thiscall*)(void*,const char*,int);using User=int(__thiscall*)(void*,int);using Local=int(__thiscall*)(void*);
 const int attacker=reinterpret_cast<User>(user)(engine,reinterpret_cast<Int>(get)(event,"attacker",-1));
 if(attacker!=reinterpret_cast<Local>(local)(engine))return;
 const int victim=reinterpret_cast<User>(user)(engine,reinterpret_cast<Int>(get)(event,"userid",-1));
 if(victim>0&&victim<=64)hit_until[victim]=GetTickCount()+700;
}
inline void __fastcall event_destroy(void*,void*,unsigned){}
inline int __fastcall event_debug(void*,void*){return 42;}
inline void* event_methods[]={reinterpret_cast<void*>(&event_destroy),reinterpret_cast<void*>(&event_received),reinterpret_cast<void*>(&event_debug)};
inline void** listener=event_methods;
inline void bind_events(){
 if(events_bound||!show_hit)return;const unsigned now=GetTickCount();if(event_retry&&int(now-event_retry)<0)return;event_retry=now+5000;
 auto* module=GetModuleHandleW(L"engine.dll");if(!module)return;
 using Factory=void*(__cdecl*)(const char*,int*);auto factory=reinterpret_cast<Factory>(GetProcAddress(module,"CreateInterface"));auto* manager=factory?factory("GAMEEVENTSMANAGER002",nullptr):nullptr;
 auto* add=local_client_interfaces::method(manager,3);if(!add)return;using Add=bool(__thiscall*)(void*,void*,const char*,bool);
 events_bound=reinterpret_cast<Add>(add)(manager,&listener,"player_hurt",false);
}
inline SkeetSDK::IRenderer* renderer=nullptr;
using Text=void(__fastcall*)(SkeetSDK::IRenderer*,int,int,int,unsigned,unsigned,const wchar_t*,unsigned);
inline Text original=nullptr;inline void* table[45]{};
struct Prop {const char* name;int type,flags,string_size;unsigned char array;unsigned char pad[3];const void* extra;Prop* array_prop;void* length_proxy;void* proxy;void* table_proxy;void* data_table;int offset,stride,count;const char* parent;};
struct Recv {Prop* props;int count;void* decoder;const char* name;};
struct Class {void* create;void* event;const char* name;Recv* table;Class* next;int id;};
static_assert(offsetof(Prop,data_table)==0x28&&offsetof(Prop,offset)==0x2c&&offsetof(Class,table)==12);
inline bool equals(const char* p,const char* expected){const auto n=std::strlen(expected);return memory(p,n+1)&&!std::memcmp(p,expected,n+1);}
inline int find(Recv* t,const char* name,unsigned depth,unsigned& budget,Recv** chain){
 if(depth>=12||!budget||!memory(t,sizeof(Recv))||t->count<0||t->count>2048||!memory(t->props,unsigned(t->count)*sizeof(Prop)))return -1;
 for(unsigned i=0;i<depth;i++)if(chain[i]==t)return -1;chain[depth]=t;
 for(int i=0;i<t->count&&budget;i++){--budget;auto& p=t->props[i];if(p.offset<0||p.offset>0x10000)continue;if(equals(p.name,name))return p.offset;
  if(p.type==6&&p.data_table){const int n=find(static_cast<Recv*>(p.data_table),name,depth+1,budget,chain);if(n>=0&&n+p.offset<0x10000)return n+p.offset;}}
 return -1;
}
inline int origin=-1,mins=-1,maxs=-1,health=-1,team=-1;inline unsigned retry=0;inline bool bound=false;
inline bool initialize(){
 if(bound)return true;const unsigned now=GetTickCount();if(retry&&int(now-retry)<0)return false;retry=now+5000;
 auto* client=GetModuleHandleW(L"client.dll");if(!client)return false;
 using Factory=void*(__cdecl*)(const char*,int*);auto f=reinterpret_cast<Factory>(GetProcAddress(client,"CreateInterface"));auto* object=f?f("VClient018",nullptr):nullptr;
 auto* method=local_client_interfaces::method(object,8);if(!method)return false;using Classes=Class*(__thiscall*)(void*);
 Class* c=reinterpret_cast<Classes>(method)(object);Recv* root=nullptr;
 for(unsigned i=0;c&&i<512;i++){if(!memory(c,sizeof(Class))||!memory(c->table,sizeof(Recv)))return false;if(equals(c->table->name,"DT_CSPlayer")){root=c->table;break;}if(c->next==c)return false;c=c->next;}
 if(!root)return false;int* fields[]={&origin,&mins,&maxs,&health,&team};const char* names[]={"m_vecOrigin","m_vecMins","m_vecMaxs","m_iHealth","m_iTeamNum"};
 for(unsigned i=0;i<5;i++){unsigned budget=5000;Recv* chain[12]{};*fields[i]=find(root,names[i],0,budget,chain);if(*fields[i]<0)return false;}bound=true;return true;
}
inline Candidate candidates[64]{};inline unsigned count=0,last_frame=~0u;inline int screen_w=0,screen_h=0;
inline bool box(const float* m,const float* o,const float* lo,const float* hi,Rect& out){
 float left=1e9f,top=1e9f,right=-1e9f,bottom=-1e9f;
 for(unsigned i=0;i<8;i++){float p[3];for(unsigned k=0;k<3;k++){p[k]=o[k]+((i&(1u<<k))?hi[k]:lo[k]);if(!std::isfinite(p[k])||std::fabs(p[k])>65536)return false;}
  const float w=m[12]*p[0]+m[13]*p[1]+m[14]*p[2]+m[15];if(!std::isfinite(w)||w<.001f)return false;
  const float x=screen_w*.5f*(1+(m[0]*p[0]+m[1]*p[1]+m[2]*p[2]+m[3])/w),y=screen_h*.5f*(1-(m[4]*p[0]+m[5]*p[1]+m[6]*p[2]+m[7])/w);
  if(!std::isfinite(x)||!std::isfinite(y)||std::fabs(x)>100000||std::fabs(y)>100000)return false;left=std::min(left,x);right=std::max(right,x);top=std::min(top,y);bottom=std::max(bottom,y);
 }
 out={int(left),int(top),int(right-left),int(bottom-top)};return out.w>1&&out.h>3&&out.w<screen_w*2&&out.h<screen_h*2;
}
inline void refresh(){
 const auto* vars=pointer(reinterpret_cast<void*>(0x43467b04),0);const unsigned frame=memory(vars,8)?read32(vars,4):GetTickCount();if(frame==last_frame)return;last_frame=frame;count=0;for(auto& b:last_bottom)b=0;
 if(!renderer||!initialize())return;
 renderer->ScreenSize(&screen_w,&screen_h);if(screen_w<320||screen_h<200)return;
 auto* entities=local_client_interfaces::core_interface(0x4346a890);auto* engine=local_client_interfaces::core_interface(0x4346a514);
 auto* get=local_client_interfaces::method(entities,3);auto* local=local_client_interfaces::method(engine,12);auto* matrix=local_client_interfaces::method(engine,37);if(!get||!local||!matrix)return;
 using Entity=void*(__thiscall*)(void*,int);using Local=int(__thiscall*)(void*);using Matrix=const float*(__thiscall*)(void*);
 const auto* m=reinterpret_cast<Matrix>(matrix)(engine);if(!memory(m,64))return;for(int i=0;i<16;i++)if(!std::isfinite(m[i]))return;
 const int index=reinterpret_cast<Local>(local)(engine);if(index<1||index>64)return;auto* me=reinterpret_cast<Entity>(get)(entities,index);if(!memory(me,team+4))return;const int my_team=int(read32(me,team));
 const unsigned bytes=unsigned(std::max({origin+12,mins+12,maxs+12,team+4,health+4}));
 for(int i=1;i<=64;i++){if(i==index)continue;auto* e=static_cast<unsigned char*>(reinterpret_cast<Entity>(get)(entities,i));if(!memory(e,bytes))continue;const int hp=int(read32(e,health)),t=int(read32(e,team));if(hp<=0||hp>5000||(t!=2&&t!=3))continue;
  auto& c=candidates[count];if(box(m,reinterpret_cast<float*>(e+origin),reinterpret_cast<float*>(e+mins),reinterpret_cast<float*>(e+maxs),c.box)){c.enemy=t!=my_team;actor[count]=unsigned(i);count++;}}
}
__declspec(noinline) inline void __fastcall text(SkeetSDK::IRenderer* self,int flags,int x,int y,unsigned color,unsigned width,const wchar_t* value,unsigned length){
 const auto caller=reinterpret_cast<std::uintptr_t>(__builtin_return_address(0));
 if(!menu_drawing&&self==renderer&&caller>=0x43310000u&&caller<0x43470000u&&length>0&&length<=32){
  bool active=show_hit;for(auto& p:placements)if(p.load(std::memory_order_relaxed)&0x80000000u){active=true;break;}
  const int id=active?flag(value,length):-1;
  if(id>=0){const auto placement=Placement::unpack(placements[id].load(std::memory_order_relaxed));if(placement.custom||show_hit){refresh();const int match=owner(candidates,count,x,y);if(match>=0){last_bottom[match]=std::max(last_bottom[match],unsigned(std::max(0,y+12)));if(placement.custom){int measured[2]{};self->MeasureText(measured,value,length,flags);if(measured[0]>0&&measured[0]<512&&measured[1]>0&&measured[1]<128){const auto at=placed(candidates[match].box,measured[0],measured[1],placement,0);x=at.x;y=at.y;}}}}}
 }
 original(self,flags,x,y,color,width,value,length);
}
inline void draw_hits(){
 if(!renderer||!show_hit)return;bind_events();refresh();
 RendererOverlayScope pass(renderer);const auto now=GetTickCount();
 for(unsigned i=0;i<count;i++)if(candidates[i].enemy&&hit_until[actor[i]]&&int(hit_until[actor[i]]-now)>0){
  const auto placement=Placement::unpack(placements[10].load());int size[2]{};renderer->MeasureText(size,L"HIT",3,0);auto at=placed(candidates[i].box,size[0],size[1],placement,0);
  if(!placement.custom)at.y=std::max(at.y,int(last_bottom[i]));renderer->Text(0,at.x,at.y,0xffeeeeee,100,L"HIT",3);
 }

}
// Lua may clone the menu renderer's vtable. Its address is not an ABI ID.
// Match the inherited methods that define this native object's state layout.
inline bool supported_renderer(SkeetSDK::IRenderer* r){
 if(!memory(r,0x84))return false;auto** vt=*reinterpret_cast<void***>(r);if(vt==table+1)return true;
 if(!memory(vt,31*4))return false;
 return vt[17]==reinterpret_cast<void*>(0x4341825cu)&&vt[18]==reinterpret_cast<void*>(0x433b0530u)&&vt[24]==reinterpret_cast<void*>(0x4339cb94u)&&vt[25]==reinterpret_cast<void*>(0x433f1e34u)&&vt[26]==reinterpret_cast<void*>(0x4331ece5u)&&vt[28]==reinterpret_cast<void*>(0x433c12dau)&&vt[30]==reinterpret_cast<void*>(0x433cfd53u);
}
inline bool install(SkeetSDK::IRenderer* r){
 if(!supported_renderer(r)||!memory(r,4,true))return false;auto** old=*reinterpret_cast<void***>(r);if(old==table+1||(original&&old[15]==reinterpret_cast<void*>(&text))){renderer=r;return true;}
 // A later Lua hook may already call our saved Text entry. Rewrapping that
 // foreign table would create Text -> Lua -> Text recursion. Keep its chain.
 if(original&&old!=reinterpret_cast<void**>(0x43472a80u)){if(renderer==r)return true;renderer=nullptr;return false;}
 if(!memory(old,44*4)||!local_client_interfaces::method(r,15))return false;
 table[0]=*reinterpret_cast<void**>(0x43472a7cu);std::memcpy(table+1,old,44*4);original=reinterpret_cast<Text>(old[15]);table[16]=reinterpret_cast<void*>(&text);
 if(InterlockedCompareExchangePointer(reinterpret_cast<void* volatile*>(r),table+1,old)!=old)return false;renderer=r;return true;
}
}
