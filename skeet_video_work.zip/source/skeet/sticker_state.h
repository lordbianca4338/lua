#pragma once
#include <array>
#include <cmath>
#include <cstdint>
#include "sticker_catalog.h"
namespace sticker_state {
struct Sticker {int id=0;float wear=0,scale=1,rotation=0;bool operator==(const Sticker& b)const{return id==b.id&&wear==b.wear&&scale==b.scale&&rotation==b.rotation;}};
inline bool gun(int n){switch(n){case 1:case 2:case 3:case 4:case 7:case 8:case 9:case 10:case 11:case 13:case 14:case 16:case 17:case 19:case 23:case 24:case 25:case 26:case 27:case 28:case 29:case 30:case 32:case 33:case 34:case 35:case 36:case 38:case 39:case 40:case 60:case 61:case 63:case 64:return true;default:return false;}}
inline bool valid(const Sticker& s){return sticker_catalog::valid(s.id)&&std::isfinite(s.wear)&&s.wear>=0&&s.wear<=1&&std::isfinite(s.scale)&&s.scale>=.1f&&s.scale<=5&&std::isfinite(s.rotation)&&s.rotation>=-180&&s.rotation<=180;}
struct Weapon {std::array<Sticker,4> slots{};unsigned revision=0;};
inline std::array<Weapon,65> weapons{};
inline unsigned revision(int w){return gun(w)?weapons[w].revision:0;}
inline bool active(int w){if(!gun(w))return false;for(auto& s:weapons[w].slots)if(s.id)return true;return false;}
inline bool set(int w,unsigned slot,Sticker s){if(!gun(w)||slot>=4||!valid(s))return false;auto& v=weapons[w];if(!(v.slots[slot]==s)){v.slots[slot]=s;++v.revision;}return true;}
}
