#pragma once
namespace menu_paint {
using namespace SkeetSDK;using menu_interaction::Rect;
inline unsigned accent(){
 // The native menu color saved/restored by saver.cpp (LCOLOR). Read the
 // actual model even when its picker is unnamed or hidden by a Lua page.
 const auto* native_color=reinterpret_cast<const void*>(0x43468fb0u);
 if(local_inventory_client::memory(native_color,4)){unsigned c;std::memcpy(&c,native_color,4);return c|0xff000000u;}

 if(context&&context->Menu&&context->Menu->Tabs.size()==9)for(auto* child:context->Menu->Tabs[MISC]->Childs)if(child&&child->Elements.size()<512)for(auto* e:child->Elements)if(e&&e->GetAs<Checkbox>()->Header.Type==UiColorPicker){wchar_t name[128]{};native_ui_names::decode(e->GetAs<Checkbox>()->Name.get(),name,128);if(eq(name,L"Menu color")){auto* v=native_ui_proxy::pointer(e,0x5c);if(v){unsigned c;std::memcpy(&c,v,4);return c|0xff000000u;}}}
 return 0xff2bc49du;
}
struct Paint {
 IRenderer* r;float dpi=1;
 int s(int n)const{return std::max(1,int(n*dpi+.5f));}
 void fill(Rect b,unsigned c){if(b.w>0&&b.h>0)r->Rect(b.x,b.y,b.w,b.h,c);}
 void border(Rect b,unsigned c){fill({b.x,b.y,b.w,1},c);fill({b.x,b.y+b.h-1,b.w,1},c);fill({b.x,b.y,1,b.h},c);fill({b.x+b.w-1,b.y,1,b.h},c);}
 void text(int x,int y,const wchar_t* t,unsigned c=0xffd0d0d0u,int width=512){if(t&&width>0)r->Text(0,x,y,c,unsigned(width),t,std::wcslen(t));}
 void gear(Rect b,unsigned c=0xffbababaU){
  const int n=std::clamp(std::min(b.w,b.h),8,40);static unsigned char mask[40*40]{};static int cached=0;
  if(cached!=n){for(int y=0;y<n;y++)for(int x=0;x<n;x++){unsigned a=0;for(int sy=0;sy<4;sy++)for(int sx=0;sx<4;sx++){
   const float dx=(x+(sx+.5f)/4)/n*2-1,dy=(y+(sy+.5f)/4)/n*2-1;const float d=dx*dx+dy*dy,angle=std::atan2(dy,dx);const float rad=std::cos(angle*8)>.15f?.93f:.72f;a+=d<rad*rad&&d>.28f*.28f;}mask[y*n+x]=a;}cached=n;}
  for(int y=0;y<n;y++)for(int x=0;x<n;){const auto a=mask[y*n+x];int end=x+1;while(end<n&&mask[y*n+end]==a)end++;if(a)fill({b.x+(b.w-n)/2+x,b.y+(b.h-n)/2+y,end-x,1},menu_interaction::opacity(c,float(a)/16));x=end;}
 }
};
}
