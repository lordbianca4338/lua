#pragma once
#include "night_mode.h"
namespace night_mode_client {
inline night_mode::State state{};inline void* system=nullptr;
inline bool initialize(){
 if(!agent_preview::module(agent_preview::materials))return false;
 const auto* base=agent_preview::materials.base;
 constexpr unsigned char first[]={0x56,0x8b,0xf1,0x57,0xbf,0xff,0xff,0,0};
 constexpr unsigned char invalid[]={0xb8,0xff,0xff,0,0,0xc3};
 if(std::memcmp(base+0x15b10,first,sizeof(first))||std::memcmp(base+0x15b50,invalid,sizeof(invalid)))return false;
 system=agent_preview::factory(agent_preview::materials,"VMaterialSystem080");
 for(unsigned slot:{86u,87u,88u,89u})if(!agent_preview::method(system,slot,agent_preview::materials))return false;return true;
}
inline unsigned short first(){return agent_preview::call<unsigned short>(system,86);}
inline unsigned short next(unsigned short h){return agent_preview::call<unsigned short>(system,87,h);}
inline void* get(unsigned short h){return agent_preview::call<void*>(system,89,h);}
inline bool method(void* m,unsigned slot){return m&&agent_preview::method(m,slot,agent_preview::materials);}
inline bool read(void* m,float* out){if(!method(m,45))return false;agent_preview::call<void>(m,45,out,out+1,out+2);for(unsigned i=0;i<3;i++)if(!std::isfinite(out[i]))return false;return true;}
inline bool describe(void* m,night_mode::Group& group,float* out){
 if(!method(m,1)||!method(m,12)||!method(m,13)||!method(m,28)||!method(m,42)||agent_preview::call<bool>(m,42))return false;
 const char* name=agent_preview::call<const char*>(m,1);if(!local_inventory_client::memory(name,6))return false;
 if(!std::memcmp(name,"World",5))group=night_mode::Group::World;
 else if(local_inventory_client::memory(name,10)&&!std::memcmp(name,"StaticProp",10))group=night_mode::Group::Props;
 else return false;return read(m,out);
}
inline void retain(void* m){agent_preview::call<void>(m,12);}
inline void release(void* m){if(method(m,13))agent_preview::call<void>(m,13);}
inline void write(void* m,const float* c){if(method(m,28))agent_preview::call<void>(m,28,c[0],c[1],c[2]);}
inline const night_mode::Api api{first,next,get,describe,retain,release,read,write};
inline void frame(){if(state.work()&&initialize())state.tick(api,GetTickCount());}
}
extern "C" {
__declspec(dllexport) void clover_night(int enabled,unsigned amount,unsigned world,unsigned props){night_mode_client::state.configure({enabled!=0,amount,world,props});}
__declspec(dllexport) void clover_night_reset(){night_mode_client::state.reset();}
}
