#pragma once
#include <cstdint>
#include <cstring>

namespace record_eligibility {
inline std::uint32_t u32(const void* p,std::size_t offset) {
    std::uint32_t v;std::memcpy(&v,static_cast<const unsigned char*>(p)+offset,4);return v;
}
inline float f32(const void* p,std::size_t offset) {
    float v;std::memcpy(&v,static_cast<const unsigned char*>(p)+offset,4);return v;
}
inline bool finite(float v) {
    std::uint32_t bits;std::memcpy(&bits,&v,4);return (bits&0x7f800000U)!=0x7f800000U;
}
struct Position {float x,y,z;};
inline Position position(const void* p,std::size_t offset) {
    return {f32(p,offset),f32(p,offset+4),f32(p,offset+8)};
}
inline bool finite(Position p) {return finite(p.x)&&finite(p.y)&&finite(p.z);}
inline bool continuous(Position a,Position b) {
    const float dx=a.x-b.x,dy=a.y-b.y,dz=a.z-b.z;
    volatile float squared=dy*dy;
    squared=squared+dx*dx;squared=squared+dz*dz;
    return finite(squared)&&squared<=4096.f;
}
// Layout belongs to the exact supplied 32-bit core. This is read-only and
// independent of ping: the original selector still owns its timing window.
inline bool eligible(const void* history,std::int32_t requested_tick) {
    if(!history)return false;
    const auto count=u32(history,0x5d8),head=u32(history,0x5d4);
    if(!count||count>32)return false;
    auto previous=position(history,0x13c);
    if(!finite(previous))return false;
    bool have_tick=false;std::int32_t previous_tick=0;
    for(std::uint32_t i=0;i<count;i++) {
        const auto address=u32(history,0x5dc+((head+i)&31)*4);
        if(!address)return false;
        const auto* record=reinterpret_cast<const void*>(static_cast<std::uintptr_t>(address));
        const auto p=position(record,0x30);
        const auto tick=static_cast<std::int32_t>(u32(record,0x4c));
        if(!finite(p)||!continuous(previous,p)||(have_tick&&tick>previous_tick))return false;
        const auto flags=u32(record,0x5c);
        if(tick<=requested_tick)
            return tick==requested_tick && (flags&4) && finite(f32(record,0x28));
        if(flags&0x200)return false; // Same stop marker as the native getter.
        previous=p;previous_tick=tick;have_tick=true;
    }
    return false;
}
}
