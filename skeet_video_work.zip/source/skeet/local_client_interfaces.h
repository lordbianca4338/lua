#pragma once
#include "local_inventory_client.h"
namespace local_client_interfaces {
using local_inventory_client::memory;using local_inventory_client::pointer;
inline void* method(void* object,unsigned slot) {
 if(!memory(object,4))return nullptr;auto* vt=pointer(object,0);if(!memory(vt,(slot+1)*4))return nullptr;
 auto* fn=pointer(vt,slot*4);MEMORY_BASIC_INFORMATION m{};
 if(!fn||!VirtualQuery(fn,&m,sizeof(m))||m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))||!(m.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY)))return nullptr;
 return fn;
}
inline void* core_interface(unsigned address) {auto* p=reinterpret_cast<void*>(address);return memory(p,4)?pointer(p,0):nullptr;}
}
