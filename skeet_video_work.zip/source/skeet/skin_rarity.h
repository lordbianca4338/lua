#pragma once
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cwchar>
#include <iterator>
#include "skin_rarity_data.h"
namespace skin_rarity {
inline void normalize(const wchar_t* source,std::size_t length,wchar_t (&out)[256]) {
    unsigned n=0;out[0]=0;if(!source)return;
    for(std::size_t i=0;i<length&&source[i]&&n<255;i++) {
        if(source[i]==7&&i+8<length) {
            bool hex=true;for(unsigned j=1;j<=8;j++)if(!((source[i+j]>=L'0'&&source[i+j]<=L'9')||
                (source[i+j]>=L'a'&&source[i+j]<=L'f')||(source[i+j]>=L'A'&&source[i+j]<=L'F')))hex=false;
            if(hex){i+=8;continue;}
        }
        if(!n&&source[i]<=L' ')continue;
        out[n++]=source[i];
    }
    while(n&&out[n-1]<=L' ')--n;out[n]=0;
}
inline const skin_rarity_data::Entry* entry(int id) {
    using namespace skin_rarity_data;
    const auto* p=std::lower_bound(std::begin(entries),std::end(entries),id,[](auto a,int b){return a.id<b;});
    return p!=std::end(entries)&&p->id==id?p:nullptr;
}
inline const skin_rarity_data::Alias* alias(const wchar_t* name) {
    using namespace skin_rarity_data;
    const auto* p=std::lower_bound(std::begin(aliases),std::end(aliases),name,[](auto a,const wchar_t* b){return std::wcscmp(a.name,b)<0;});
    return p!=std::end(aliases)&&!std::wcscmp(p->name,name)?p:nullptr;
}
inline const skin_rarity_data::Entry* resolve(int id,const wchar_t* name) {
    using namespace skin_rarity_data;
    if(const auto* e=entry(id)) {
        const auto* p=std::lower_bound(std::begin(id_aliases),std::end(id_aliases),id,[](auto a,int b){return a.id<b;});
        for(;p!=std::end(id_aliases)&&p->id==id;++p)if(!std::wcscmp(p->name,name))return e;
    }
    const auto* a=alias(name);return a&&a->id>=0?entry(a->id):nullptr;
}
inline int paint_id(int id,const wchar_t* label,std::size_t length) {
    wchar_t name[256]{};normalize(label,length,name);const auto* e=resolve(id,name);return e?e->id:-1;
}
inline int tier(int id,const wchar_t* label,std::size_t length,int weapon=0) {
    using namespace skin_rarity_data;wchar_t name[256]{};normalize(label,length,name);if(!name[0])return 0;
    if(const auto* e=resolve(id,name)) {
        if(weapon) {
            const auto* p=std::lower_bound(std::begin(variants),std::end(variants),e->id,[](auto a,int b){return a.paint<b;});
            for(;p!=std::end(variants)&&p->paint==e->id;++p)if(p->weapon==weapon)return p->rarity;
            return 0;
        }
        return e->rarity;
    }
    const auto* a=alias(name);if(!a)return 0;
    if(weapon) {
        int grade=-1;
        for(unsigned i=0;i<a->count;i++) {
            const int paint=alias_paints[a->first+i];
            const auto* p=std::lower_bound(std::begin(variants),std::end(variants),paint,[](auto v,int id){return v.paint<id;});
            for(;p!=std::end(variants)&&p->paint==paint;++p)if(p->weapon==weapon) {
                if(grade>=0&&grade!=p->rarity)return 0;grade=p->rarity;
            }
        }
        return grade>=0?grade:0;
    }
    return a->rarity;
}
inline std::uint32_t color(int id,const wchar_t* name,std::size_t length,unsigned alpha=255,int weapon=0) {
    const int rarity=tier(id,name,length,weapon);const auto c=skin_rarity_data::colors[rarity>=0&&rarity<=7?rarity:0];
    return (c&0xffffffU)|(std::min(alpha,255U)<<24);
}
// Infers a context only if every resolvable displayed finish is compatible with
// the same single weapon. Global lists and ambiguous sets stay context-free.
struct WeaponCandidates {
    int ids[128]{};unsigned size=0;bool initialized=false;
    void add(int paint) {
        using namespace skin_rarity_data;if(paint<0)return;
        int next[128]{};unsigned n=0;
        const auto* p=std::lower_bound(std::begin(variants),std::end(variants),paint,[](auto a,int b){return a.paint<b;});
        for(;p!=std::end(variants)&&p->paint==paint;++p) {
            bool keep=!initialized;
            for(unsigned i=0;!keep&&i<size;i++)keep=ids[i]==p->weapon;
            if(keep&&n<std::size(next))next[n++]=p->weapon;
        }
        if(!initialized&&!n)return;
        std::copy(next,next+n,ids);size=n;initialized=true;
    }
    int weapon()const{return initialized&&size==1?ids[0]:0;}
};
}
