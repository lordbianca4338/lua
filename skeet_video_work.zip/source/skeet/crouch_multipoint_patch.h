#pragma once
#include "scan_patch.h"
#include <initializer_list>
#include "crouch_multipoint.h"
namespace crouch_multipoint_patch {
inline constexpr unsigned code_size=512,append=0x4332325f;
inline constexpr unsigned sites[]={0x4e8f2,0x4eebb};
inline constexpr unsigned char original[2][5]={{0xe8,0x68,0x49,0xfc,0xff},{0xe8,0x9f,0x43,0xfc,0xff}};
inline constexpr unsigned char append_original[]={0x56,0x8b,0x74,0x24,0x0c,0x57,0x8b,0x79,0x04,0x6a,0x06,0x8d,0x47,0x18,0x89,0x41,0x04,0x59,0xf3,0xa5,0x5f,0x5e,0xc2,0x08,0x00};
inline constexpr unsigned char duck_capture[]={0xa1,0xf8,0x79,0x46,0x43,0x8b,0x00,0x33,0x05,0xf8,0x75,0x46,0x43,0x35,0xcf,0xc0,0x09,0x33,0x8b,0x04,0x28,0x89,0x43,0x3c};
inline constexpr unsigned char anchor0[]={0x8d,0x84,0x24,0xf4,0x02,0x00,0x00,0x50,0xff,0xb4,0x24,0x28,0x01,0x00,0x00,0x8d,0x8c,0x24,0x58,0x12,0x00,0x00,0xe8,0x90,0x49,0xfc,0xff};
inline constexpr unsigned char anchor1[]={0x57,0xff,0xb4,0x24,0x28,0x01,0x00,0x00,0x8d,0x8c,0x24,0x58,0x12,0x00,0x00};
inline constexpr unsigned char anchor2[]={0x8d,0x84,0x24,0x54,0x02,0x00,0x00,0x50,0xff,0xb4,0x24,0xdc,0x00,0x00,0x00,0x8d,0x8c,0x24,0x58,0x12,0x00,0x00,0xe8,0xc7,0x43,0xfc,0xff};
inline constexpr unsigned char anchor3[]={0x56,0xff,0xb4,0x24,0xdc,0x00,0x00,0x00,0x8d,0x8c,0x24,0x58,0x12,0x00,0x00};
struct Plan {unsigned char code[code_size]{};unsigned char calls[2][5]{};};
inline bool make(const unsigned char* image,std::size_t size,unsigned location,unsigned first,unsigned second,unsigned gate,Plan& out) {
    if(!image||size!=scan_patch::image_size||!first||!second||!gate)return false;
    for(unsigned i=0;i<2;i++)if(std::memcmp(image+sites[i],original[i],5))return false;
    if(std::memcmp(image+(append-scan_patch::image_base),append_original,sizeof(append_original))||
       std::memcmp(image+0xed7f9,duck_capture,sizeof(duck_capture)))return false;
    if(std::memcmp(image+0x4e8b4,anchor0,sizeof(anchor0)))return false;
    if(std::memcmp(image+0x4e8e3,anchor1,sizeof(anchor1)))return false;
    if(std::memcmp(image+0x4ee7d,anchor2,sizeof(anchor2)))return false;
    if(std::memcmp(image+0x4eeac,anchor3,sizeof(anchor3)))return false;
    Plan p{};
    for(unsigned entry=0;entry<2;entry++) {
        unsigned n=entry*256;
        const auto bytes=[&](const unsigned char* b,unsigned len){std::memcpy(p.code+n,b,len);n+=len;};
        const auto byte=[&](unsigned char b){p.code[n++]=b;};
        const auto dword=[&](unsigned v){std::memcpy(p.code+n,&v,4);n+=4;};
        const auto jz=[&](){byte(0x0f);byte(0x84);const unsigned at=n;dword(0);return at;};
        // Save flags and GP registers, then avoid FXSAVE/helper overhead for OFF
        // and standing/low-duck targets. The native caller supplies this job.
        byte(0x9c);byte(0x60);byte(0x83);byte(0x3d);dword(gate);byte(0);const unsigned off=jz();
        const unsigned char job[]={0x8b,0x45,0x1c,0x85,0xc0};bytes(job,sizeof(job));const unsigned missing=jz();
        byte(0x8b);byte(0x90);dword(0x12c);
        byte(0x81);byte(0xfa);dword(0x3f0ccccd);byte(0x0f);byte(0x86);const unsigned standing=n;dword(0);
        const unsigned char save[]={0x89,0xe6,0x81,0xec,0x40,0x02,0,0,0x83,0xe4,0xf0,0x0f,0xae,0x04,0x24,
            0x8d,0x84,0x24,0x00,0x02,0,0,0x50,0x8d,0x4e,0x24,0x8b,0xd5,0xb8};
        bytes(save,sizeof(save));dword(entry?second:first);byte(0xff);byte(0xd0);
        byte(0x85);byte(0xc0);byte(0x74);byte(10);
        const unsigned char use_copy[]={0x8d,0x84,0x24,0x00,0x02,0,0,0x89,0x46,0x2c};bytes(use_copy,sizeof(use_copy));
        const unsigned char restore[]={0x0f,0xae,0x0c,0x24,0x89,0xf4};bytes(restore,sizeof(restore));
        const unsigned common=n;byte(0x61);byte(0x9d);byte(0xe9);dword(append-(location+n+4));
        for(unsigned at:{off,missing,standing})scan_patch::put32(p.code+at,common-(at+4));
        p.calls[entry][0]=0xe8;scan_patch::put32(p.calls[entry]+1,location+entry*256-(scan_patch::image_base+sites[entry]+5));
    }
    out=p;return true;
}
#ifdef _WIN32
inline bool apply(unsigned char* image,std::size_t size) {
    if(reinterpret_cast<std::uintptr_t>(image)!=scan_patch::image_base)return false;
    auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));if(!code)return false;
    if(std::memcmp(image+0x4e8b4,anchor0,sizeof(anchor0)))return false;
    if(std::memcmp(image+0x4e8e3,anchor1,sizeof(anchor1)))return false;
    if(std::memcmp(image+0x4ee7d,anchor2,sizeof(anchor2)))return false;
    if(std::memcmp(image+0x4eeac,anchor3,sizeof(anchor3)))return false;
    Plan p{};
    if(!make(image,size,reinterpret_cast<unsigned>(code),reinterpret_cast<unsigned>(&crouch_multipoint::primary),reinterpret_cast<unsigned>(&crouch_multipoint::secondary),reinterpret_cast<unsigned>(&crouch_multipoint::enabled),p)) {
        VirtualFree(code,0,MEM_RELEASE);SetLastError(ERROR_REVISION_MISMATCH);return false;
    }
    std::memcpy(code,p.code,sizeof(p.code));DWORD old=0;
    if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&old)||!FlushInstructionCache(GetCurrentProcess(),code,sizeof(p.code))) {
        const auto error=GetLastError();VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    for(unsigned i=0;i<2;i++)std::memcpy(image+sites[i],p.calls[i],5);
    if(!FlushInstructionCache(GetCurrentProcess(),image,size)) {
        const auto error=GetLastError();for(unsigned i=0;i<2;i++)std::memcpy(image+sites[i],original[i],5);
        FlushInstructionCache(GetCurrentProcess(),image,size);VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    return true;
}
#endif
}
