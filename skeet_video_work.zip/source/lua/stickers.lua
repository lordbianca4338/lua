-- Four slots belong to the selected native Weapon skin profile, not a paint-kit
-- guessed from the unfiltered finish list. None removes the selected slot.
local kits=CLOVER_LEGACY_STICKERS
local by_id,search={},{}
for _,kit in ipairs(kits) do by_id[kit[1]]=kit[2];search[#search+1]={kit[1],kit[2],kit[2]:lower()} end
local group,label
for _,container in ipairs({'Model options','Knife options','Weapon skin'}) do
 local ok,ref=pcall(ui.new_label,'SKINS',container,'Stickers')
 if ok then group={'SKINS',container};label=ref;break end
end
if not group then error('Skin controls container unavailable') end
local slot=ui.new_combobox(group[1],group[2],'Sticker slot','Slot 1','Slot 2','Slot 3','Slot 4')
local filter=ui.new_textbox(group[1],group[2],'Find sticker')
local choice=ui.new_combobox(group[1],group[2],'Sticker','None','Search by name')
local wear=ui.new_slider(group[1],group[2],'Sticker wear',0,100,0,true,'%',1)
local size=ui.new_slider(group[1],group[2],'Sticker scale',10,500,100,true,'x',.01)
local rotation=ui.new_slider(group[1],group[2],'Sticker rotation',-180,180,0,true,'°',1)
local stored=database.read('clover.8802.stickers.v1') or {}
local data={}
if type(stored)=='table' then for weapon,rows in pairs(stored) do
 if type(rows)=='table' and tonumber(weapon) then for s=1,4 do
  local st=rows[s];if type(st)=='table' and by_id[tonumber(st[1])] then
   local id,w,sc,rot=tonumber(st[1]),tonumber(st[2]) or 0,tonumber(st[3]) or 1,tonumber(st[4]) or 0
   if native.clover_sticker_set(tonumber(weapon),s-1,id,w,sc,rot)==1 then local key=tostring(tonumber(weapon));data[key]=data[key] or {};data[key][s]={id,w,sc,rot} end
  end
 end end
end end
local function encode()
 local rows={'v1'}
 for w=1,64 do local slots=data[tostring(w)];if slots then for s=1,4 do local v=slots[s];if v then rows[#rows+1]=string.format('%d,%d,%d,%.6g,%.6g,%.6g',w,s,v[1],v[2],v[3],v[4]) end end end end
 return table.concat(rows,';')..';'
end
-- Use one hidden string for all per-weapon slots when the core exposes it.
-- An indexed, filtered combo is never used as the config's sticker identity.
local config_store
if type(ui.new_string)=='function' then local ok,ref=pcall(ui.new_string,'Clover sticker profiles 8802',encode());if ok then config_store=ref end end
local config_loading=false
local function persist()
 database.write('clover.8802.stickers.v1',data)
 if config_store then ui.set(config_store,encode()) end
end
local function decode(text)
 if type(text)~='string' or #text>32768 or text:sub(1,3)~='v1;' then return end
 local next_data={};local count=0
 for row in text:sub(4):gmatch('[^;]+') do
  count=count+1;if count>256 then return end
  if select(2,row:gsub(',',''))~=5 then return end
  local v={};for n in row:gmatch('[^,]+') do local number=tonumber(n);if not number then return end;v[#v+1]=number end
  if #v~=6 then return end
  local w,s,id,wear,sc,rot=unpack(v)
  if not w or w~=math.floor(w) or w<1 or w>64 or not s or s~=math.floor(s) or s<1 or s>4 or not by_id[id] or wear~=wear or wear<0 or wear>1 or sc~=sc or sc<.1 or sc>5 or rot~=rot or rot< -180 or rot>180 then return end
  local probe=ffi.new('CloverSticker8802[1]');if native.clover_sticker_get(w,0,probe)~=1 then return end
  local key=tostring(w);next_data[key]=next_data[key] or {};next_data[key][s]={id,wear,sc,rot}
 end
 return next_data
end
local active,active_slot,query,changing,options=0,-1,'',false,{}
local value=ffi.new('CloverSticker8802[1]')
local function get()
 local s=tonumber(ui.get(slot):match('%d+'))-1
 if native.clover_sticker_get(active,s,value)~=1 then return end
 return s,value[0]
end
local function title(id) return id==0 and 'None' or string.format('%s [%d]',by_id[id] or 'Unknown',id) end
local function list(current)
 local q=ui.get(filter):lower();query=q;options={{0,'None'}}
 if current~=0 then options[#options+1]={current,title(current)} end
 for _,kit in ipairs(search) do
  if kit[1]~=0 and kit[1]~=current and (q=='' or kit[3]:find(q,1,true)) then options[#options+1]={kit[1],title(kit[1])};if #options>=62 then break end end
 end
 local names={};for _,v in ipairs(options) do names[#names+1]=v[2] end
 ui.update(choice,unpack(names));ui.set(choice,title(current))
end
local function bind()
 local s,st=get();if s==nil then return end
 changing=true;active_slot=s;list(tonumber(st.id));ui.set(wear,math.floor(st.wear*100+.5));ui.set(size,math.floor(st.scale*100+.5));ui.set(rotation,math.floor(st.rotation+.5));changing=false
end
local function apply()
 if changing or config_loading or active==0 then return end
 local s,st=get();if s==nil then return end
 local selected=ui.get(choice);local id=0;for _,v in ipairs(options) do if v[2]==selected then id=v[1];break end end
 local w,sc,rot=ui.get(wear)/100,ui.get(size)/100,ui.get(rotation)
 if native.clover_sticker_set(active,s,id,w,sc,rot)~=1 then return end
 local key=tostring(active);data[key]=data[key] or {};data[key][s+1]={id,w,sc,rot};persist()
end
ui.set_callback(slot,function() if not config_loading then bind() end end)
ui.set_callback(filter,function() if changing or config_loading then return end;local s,st=get();if s~=nil then changing=true;list(tonumber(st.id));changing=false end end)
for _,ref in ipairs({choice,wear,size,rotation}) do ui.set_callback(ref,apply) end
local last=-1
client.set_event_callback('paint_ui',function()
 local now=globals.realtime();if now-last<.1 then return end;last=now
 local weapon=native.clover_selected_weapon();local valid=native.clover_sticker_get(weapon,0,value)==1
 for _,ref in ipairs({label,slot,filter,choice,wear,size,rotation}) do ui.set_visible(ref,valid) end
 if valid and weapon~=active then active=weapon;bind() end
end)

client.set_event_callback('pre_config_load',function() config_loading=true end)
client.set_event_callback('post_config_load',function()
 if config_store then
  local next_data=decode(ui.get(config_store))
  if next_data then
   local probe=ffi.new('CloverSticker8802[1]')
   for w=1,64 do if native.clover_sticker_get(w,0,probe)==1 then for s=1,4 do
    local slots=next_data[tostring(w)];local v=slots and slots[s] or {0,0,1,0};native.clover_sticker_set(w,s-1,v[1],v[2],v[3],v[4])
   end end end
   data=next_data;database.write('clover.8802.stickers.v1',data)
  end
 end
 config_loading=false;active=0;active_slot=-1
end)
client.set_event_callback('pre_config_save',persist)
