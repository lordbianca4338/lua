-- Private DLL operations use native UI callbacks. No FFI function calls.
local input,output={},{}
local function hidden(method,name,...)
 local ref=native_ui[method]('LUA','A',name,...);native_ui.set_visible(ref,false);return ref
end
local request=hidden('new_checkbox','Clover bridge request 8802')
local ready=hidden('new_slider','Clover bridge ready 8802',0,10000,0,false)
for i=0,31 do input[i]=hidden('new_slider','Clover bridge in '..i,-1000000000,1000000000,0,false) end
for i=0,7 do output[i]=hidden('new_slider','Clover bridge out '..i,-1000000000,1000000000,0,false) end
local sequence,bridge_failed=0,false
local function rpc(op,args,text)
 if bridge_failed or native_ui.get(ready)~=8802 then return 0 end
 sequence=sequence%1000000+1
 for i=1,6 do native_ui.set(input[i],args and args[i] or 0) end
 if op==9 or op==10 then
  text=text or '';if #text>95 then return 0 end
  for n=0,23 do
   local value=0;for j=1,4 do local c=text:byte(n*4+j) or 0;if c>127 then return 0 end;value=value+c*128^(j-1) end
   if value>2147483647 then return 0 end
   native_ui.set(input[7+n],value)
  end
 end
 native_ui.set(input[0],op);native_ui.set(input[31],sequence)
 native_ui.set(request,not native_ui.get(request))
 if native_ui.get(output[7])~=sequence then
  bridge_failed=true;client.error_log('Clover: native UI bridge unavailable; module startup stopped');return 0
 end
 return native_ui.get(output[0])
end
local function fixed(v) return math.floor(v*10000+.5) end
-- Data containers only; engine calls never pass through this adapter.
local ffi={new=function() return {[0]={id=0,wear=0,scale=1,rotation=0,valid=0}} end,sizeof=function() return 28 end}
local native={}
function native.clover_ui_heartbeat() return rpc(1) end
function native.clover_ui_module(mask) return rpc(2,{mask}) end
function native.clover_night(on,amount,world,props) return rpc(3,{on,amount,world,props}) end
function native.clover_night_reset() return rpc(4) end
function native.clover_telemetry(out)
 local ok=rpc(5);if ok==1 then out[0]={valid=native_ui.get(output[1]),cpu_percent=native_ui.get(output[2])/10000,cpu_ghz=native_ui.get(output[3])/10000,ram_used_gib=native_ui.get(output[4])/10000,ram_total_gib=native_ui.get(output[5])/10000,process_mib=native_ui.get(output[6])/10000} end;return ok
end
function native.clover_selected_weapon() return rpc(6) end
function native.clover_sticker_set(w,s,id,wear,scale,rotation) return rpc(7,{w,s,id,fixed(wear),fixed(scale),fixed(rotation)}) end
function native.clover_sticker_get(w,s,out)
 local ok=rpc(8,{w,s});if ok==1 then out[0]={id=native_ui.get(output[1]),wear=native_ui.get(output[2])/10000,scale=native_ui.get(output[3])/10000,rotation=native_ui.get(output[4])/10000} end;return ok
end
function native.clover_sky(name) return rpc(9,nil,name) end
function native.clover_sky_tint(name,color) return rpc(10,{color},name) end
local last_heartbeat=-10
client.set_event_callback('paint_ui',function()
 local now=globals.realtime();if now-last_heartbeat>=.5 then last_heartbeat=now;native.clover_ui_heartbeat() end
end)
local hw,hw_time={[0]={valid=0}},-10
local function hardware()
 local now=globals.realtime();if now-hw_time>=1 then hw_time=now;native.clover_telemetry(hw) end;return hw[0]
end
local function bridge_ready() return native_ui.get(ready)==8802 and rpc(0)==8802 end
