#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <cmath>
#include "../source/skeet/local_inventory_client.h"
namespace SkeetSDK {struct IRenderer {
#define SLOT(n) virtual void slot##n()=0;
 SLOT(0) SLOT(1) SLOT(2) SLOT(3) SLOT(4) SLOT(5) SLOT(6) SLOT(7) SLOT(8) SLOT(9) SLOT(10) SLOT(11) SLOT(12) SLOT(13) SLOT(14) SLOT(15) SLOT(16) SLOT(17) SLOT(18)
#undef SLOT
 virtual int __fastcall AddTexture(unsigned char*,int,int,std::size_t,int,int)=0;
};}
#include "../source/skeet/agent_preview_native.h"
extern "C" {
__declspec(dllexport) unsigned agent_thunk_probe(){return reinterpret_cast<unsigned>(&agent_preview::capture_bones_thunk);}
__declspec(dllexport) unsigned agent_joints_probe(){return agent_preview::player.joint_count;}
__declspec(dllexport) int agent_initialize_probe(){return agent_preview::initialize();}
__declspec(dllexport) int agent_render_probe(unsigned now,int subject,unsigned material,unsigned rgba){return agent_preview::render(now,subject,{static_cast<agent_preview::Material>(material),rgba});}
__declspec(dllexport) int agent_gpu_probe(void* renderer){return agent_preview::gpu_texture(static_cast<SkeetSDK::IRenderer*>(renderer));}
__declspec(dllexport) void agent_pause_probe(){agent_preview::pause();}
__declspec(dllexport) unsigned agent_model_probe(int which){return reinterpret_cast<unsigned>(which?agent_preview::weapon.bytes:agent_preview::player.bytes);}
}
