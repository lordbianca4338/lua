#include "../source/skeet/cs2_visuals_design.h"
#include "../source/skeet/cs2_visuals_hook.h"
#include <fstream>
#include <cassert>
#include <iostream>
using namespace cs2_visuals;
int main(int argc,char**argv) {
    for(std::uint32_t page:{0x200000u,0x18000000u,0x70000000u}) {
        auto h=config_hook_plan(0x43310000,page,page+64);std::uint32_t delta=0;
        assert(!std::memcmp(h.trampoline,config_prefix,8)&&h.trampoline[8]==0xe9&&h.entry[0]==0xe9);
        std::memcpy(&delta,h.trampoline+9,4);assert(page+13+delta==0x43310000+config_offset+8);
        std::memcpy(&delta,h.entry+1,4);assert(std::uint32_t(0x43310000+config_offset+5+delta)==page+64);
    }
    unsigned cases=0;
    for(float scale:{1.f,1.25f,1.5f,2.f})for(int width:{620,660,800})for(int height:{480,560,700}) {
        const int w=int(width*scale),h=int(height*scale);auto l=layout(w,h,scale);
        assert(l.category.x>0&&l.category.x+l.category.w<=w);
        for(auto r:l.panels){assert(r.y>=l.category.y+l.category.h&&r.x+r.w<=w&&r.y+r.h<=h);}
        for(auto r:l.icons){assert(r.x>=l.category.x&&r.x+r.w<=l.category.x+l.category.w);}
        assert(l.panels[OtherESP].h>l.panels[WorldModels].h);
        assert(l.panels[WorldModels].y+l.panels[WorldModels].h<l.panels[Effects].y);
        assert(l.panels[HelperSettings].x<l.panels[HelperEffects].x);
        for(int cat=0;cat<category_count;cat++) {
            Scene s;category_scene(s,l.category,l.icons,cat,category_count,scale,1);
            assert(s.count<s.commands.size()&&s.count>100);
            category_scene(s,l.category,l.icons,cat,category_count,scale,0);
            for(unsigned i=0;i<s.count;i++)assert(s.commands[i].color.a==0);
            ++cases;
        }
    }
    assert(route(L"Player ESP",L"Name")== (bit(EnemyESP)|bit(TeamESP)));
    assert(route(L"Player ESP",L"Teammates")==bit(TeamESP));
    assert(route(L"Player ESP",L"Glow")== (bit(EnemyModels)|bit(TeamModels)));
    assert(route(L"Colored models",L"Teammate behind wall")==bit(TeamModels));
    assert(route(L"Colored models",L"Weapons")==bit(WorldModels));
    assert(route(L"Effects",L"Override skybox")==bit(HelperEffects));
    assert(route(L"Other ESP",L"Grenades")==bit(OtherESP));
    assert(route(L"Effects",L"Remove smoke grenades")==bit(Effects));
    assert(route(L"Effects",L"Force third person (alive)")==bit(ViewPanel));
    assert(route(L"Other ESP",L"Spectators")==bit(HUD));
    assert(!route(L"Miscellaneous",L"Override FOV",true));
    assert(!route(L"Miscellaneous",L"Knifebot",true));
    assert(route(L"Danger Zone items",L"Ammobox")==bit(DangerItems));
    if(argc>1){
        std::ofstream out(argv[1]);auto l=layout(660,560);out<<"{\"category\":["<<l.category.x<<','<<l.category.y<<','<<l.category.w<<','<<l.category.h<<"],\"panels\":[";
        for(int i=0;i<panel_count;i++){if(i)out<<',';auto r=l.panels[i];out<<'['<<r.x<<','<<r.y<<','<<r.w<<','<<r.h<<']';}
        out<<"],\"scenes\":[";
        for(int cat=0;cat<category_count;cat++){
            if(cat)out<<',';Scene s;category_scene(s,l.category,l.icons,cat,category_count,1,1);out<<'[';
            for(unsigned i=0;i<s.count;i++){if(i)out<<',';auto c=s.commands[i];out<<'['<<int(c.kind)<<','<<c.r.x<<','<<c.r.y<<','<<c.r.w<<','<<c.r.h<<','<<c.color.pack()<<']';}out<<']';
        }out<<"]}\n";
    }
    if(argc>3){auto loc=std::uint32_t(std::stoul(argv[3],nullptr,0));auto callback=argc>4?std::uint32_t(std::stoul(argv[4],nullptr,0)):loc+0x100;auto p=render_hook_plan(0x43310000,loc,callback);std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<const char*>(&p),sizeof(p));}
    std::cout<<cases<<" geometry/scene checks and 11 routing checks passed\n";
}
