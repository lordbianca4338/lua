#include "../source/skeet/crouch_multipoint_patch.h"
#include <fstream>
#include <iterator>
#include <vector>
#include <cassert>
#include <iostream>
int main(int argc,char** argv) {
    assert(argc==7);std::ifstream in(argv[1],std::ios::binary);
    std::vector<unsigned char> image((std::istreambuf_iterator<char>(in)),{});
    const unsigned address=std::stoul(argv[3],nullptr,0),first=std::stoul(argv[4],nullptr,0),second=std::stoul(argv[5],nullptr,0),gate=std::stoul(argv[6],nullptr,0);
    crouch_multipoint_patch::Plan plan{};
    assert(crouch_multipoint_patch::make(image.data(),image.size(),address,first,second,gate,plan));
    unsigned rejected=0;
    for(unsigned at:{crouch_multipoint_patch::sites[0],crouch_multipoint_patch::sites[1],0x1325fu,0xed7f9u,0x4e8b4u,0x4e8e3u,0x4ee7du,0x4eeacu}) {
        auto bad=image;bad[at]^=1;crouch_multipoint_patch::Plan no{};
        assert(!crouch_multipoint_patch::make(bad.data(),bad.size(),address,first,second,gate,no));++rejected;
    }
    std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<const char*>(&plan),sizeof(plan));
    std::cout<<rejected<<" native-site/dependency guard cases passed\n";
}
