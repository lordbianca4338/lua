"""Execute production lifecycle with controlled native allocation/UI boundaries.
Source script pages are unmapped before pending callbacks and frame refreshes.
"""
def check_lifecycle(ns):
    globals().update(ns)
    u=fixture();pe,exp=load(u,'visuals_binding_probe.dll')
    api_base=0x140000;u.mem_map(api_base,0x1000)
    u.mem_map(0x400000,0x1000);u.mem_map(0x500000,0x200000)
    ctx,menu,children,controls,tabs,visuals,misc,original,elements,api,vt=[MEM+0x10000+i*0x1000 for i in range(11)]
    native_source=0x400000;native_value=MEM+0x25000
    store(u,ctx,1);store(u,ctx+0x10,menu)
    store(u,menu+0x14,660);store(u,menu+0x18,560);store(u,menu+0x34,1);store(u,menu+0x64,3)
    store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36)
    for i in range(9):store(u,tabs+4*i,MEM+0x30000+i*0x100)
    store(u,tabs+3*4,visuals);store(u,tabs+4*4,misc)
    lua=word(u,tabs+8*4);store(u,lua+0x70,MEM+0x32000);store(u,lua+0x74,MEM+0x32008);store(u,MEM+0x32004,MEM+0x32100)
    vchildren=MEM+0x33000;store(u,visuals+0x70,vchildren);store(u,visuals+0x74,vchildren+52);store(u,visuals+0x78,vchildren+256)
    store(u,vchildren,original);u.mem_write(original+0x15,b'\1')
    def name(object,text):
        ptr=object+0x200;data=text.encode('utf-16le')
        store(u,object+0x38,ptr);u.mem_write(ptr,struct.pack('<HH',0,len(data))+data)
    name(original,'Player ESP')
    store(u,original+0x80,elements);store(u,original+0x84,elements+4);store(u,original+0x88,elements+256);store(u,elements,native_source)
    def source(address,value,text='Name',kind=3):
        store(u,address,vt);u.mem_write(address+0x14,bytes([1,1,0,1,0,kind]));store(u,address+0x5c,value);name(address,text)
    source(native_source,native_value);store(u,native_value,0x5a)
    store(u,vt+20,api_base+0x500);store(u,vt+28,api_base+0x520)
    proxy_vt=MEM+0x34000
    for offset,target in [(0,0x420),(20,0x400),(24,0x440)]:store(u,proxy_vt+offset,api_base+target)
    for i in range(12):
        p=MEM+0x40000+i*0x1000;store(u,children+4*i,p);store(u,vchildren+4*(i+1),p)
        vec=MEM+0x50000+i*0x1000
        store(u,p+0x80,vec);store(u,p+0x84,vec);store(u,p+0x88,vec+512)
    for i in range(6):
        p=MEM+0x60000+i*0x100;store(u,controls+4*i,p)
        # The category callback vector must never be cleared by invalidation.
        store(u,p+0x40,MEM+0x61000+16*i);store(u,p+0x44,MEM+0x61008+16*i);store(u,p+0x48,MEM+0x61008+16*i)
    # Put the real category buttons into their child's element vector too.
    category=word(u,children+44);vec=word(u,category+0x80)
    for i in range(6):store(u,vec+4*i,word(u,controls+4*i))
    store(u,category+0x84,vec+24)
    floats(u,0x4346d490,1)
    allocations=[];created=[];destroyed=[];callbacks=[];draws=[]
    def alloc(n):
        p=0x500000+len(allocations)*0x200;assert n<=0x200
        allocations.append((p,n));u.mem_write(p,bytes(0x200));return p
    def insert(parent,view):
        end=word(u,parent+0x84);assert end+4<=word(u,parent+0x88)
        store(u,end,view);store(u,parent+0x84,end+4)
    def mock(u,a,size,user):
        if not api_base<=a<api_base+0x1000:return
        sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);this=u.reg_read(UC_X86_REG_ECX);result=0;cleanup=4
        if a==api_base+0x100:result=alloc(this)
        elif a==api_base+0x140:
            parent,nm,value=[word(u,sp+i) for i in [4,8,12]];cleanup=16
            assert wide(u,nm) in ['Name','Script option','World option','Helper','Show locations behind walls']
            store(u,this,proxy_vt);store(u,this+0x10,parent);store(u,this+0x5c,value);u.mem_write(this+0x19,b'\3')
            # Native constructors may initialize storage. create() must restore it.
            u.mem_write(value,b'\0');created.append(this);result=this
        elif a==api_base+0x580:
            store(u,this,proxy_vt);store(u,this+0x10,word(u,sp+4));u.mem_write(this+0x19,b'\x0a');created.append(this);cleanup=8;result=this
        elif a==api_base+0x220:
            assert word(u,sp+4)==0;insert(this,word(u,sp+8));cleanup=12
        elif a==api_base+0x420:
            assert word(u,sp+4)==1;assert word(u,this+0x5c)==0;destroyed.append(this);cleanup=8
        elif a==api_base+0x440:
            u.mem_write(this+0x16,b'\0');u.mem_write(this+0x6c,b'\0')
        elif a==api_base+0x480:draws.append(this);cleanup=8
        elif a==api_base+0x500:callbacks.append(('config',this))
        elif a==api_base+0x520:callbacks.append(('value',this))
        elif a==api_base+0x540: # Native AddButton, constructor plus insertion.
            same,nm,context,callback=[word(u,sp+i) for i in [4,8,12,16]];cleanup=20
            assert wide(u,nm)=='Script action'
            view=alloc(0x64);store(u,view,proxy_vt);store(u,view+0x10,this);u.mem_write(view+0x19,b'\2')
            ptr=alloc(8);store(u,ptr,context);store(u,ptr+4,callback)
            for off,v in [(0x40,ptr),(0x44,ptr+8),(0x48,ptr+8)]:store(u,view+off,v)
            insert(this,view);created.append(view);result=view
        else:assert a in [api_base+0x400,api_base+0x460,api_base+0x560],hex(a)
        u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,mock)
    for i in range(12):store(u,api+4*i,api_base+0x100+0x20*i)
    call(u,exp('category_setup_probe'),[ctx,children,controls,api_base+0x460])
    call(u,exp('lifecycle_setup_probe'),[api,api_base+0x560,api_base+0x480,api_base+0x540])
    call(u,exp('visuals_text_ctor_probe'),[api_base+0x580])
    assert call(u,exp('lifecycle_rebuild_probe'))==1
    call(u,exp('choose_category_probe'),[1]);cases=0
    def verify(items):
        assert call(u,exp('lifecycle_status_probe'))==257 # attached + Team category
        assert word(u,native_value)==0x5a
        assert bytes(u.mem_read(original+0x15,1))==b'\0'
        for panel in [0,2]:
            child=word(u,children+4*panel);assert (word(u,child+0x84)-word(u,child+0x80))//4==items
        for i in range(6):assert word(u,word(u,controls+4*i)+0x44)==MEM+0x61008+16*i
        assert not callbacks
    def frame():call(u,exp('render_callback_probe'),[0],menu)
    verify(1)
    for cycle in range(12):
        # Load: append a checkbox and button while keeping native source stable.
        script=0x401000;script_value=0x402000;button=0x403000
        u.mem_map(script,0x3000);source(script,script_value,'Script option');store(u,script_value,0x39)
        source(button,0,'Script action',2)
        store(u,elements+4,script);store(u,elements+8,button);store(u,original+0x84,elements+12)
        frame();verify(3);assert word(u,script_value)==0x39;cases+=1
        # Other Lua widgets in Misc must not disable Visuals.
        mchildren=MEM+0x35000;mchild=MEM+0x36000;melements=MEM+0x37000
        store(u,misc+0x70,mchildren);store(u,misc+0x74,mchildren+4);store(u,mchildren,mchild)
        name(mchild,'Miscellaneous');store(u,mchild+0x80,melements);store(u,mchild+0x84,melements+4);store(u,melements,button)
        frame();verify(3);cases+=1
        # Unload before queued proxy callback; source and model memory are gone.
        store(u,original+0x84,elements+4);store(u,misc+0x74,mchildren)
        u.mem_unmap(script,0x3000)
        call(u,exp('lifecycle_callback_probe'),[2])
        assert call(u,exp('lifecycle_status_probe'))==258 # rebuild scheduled, same category
        assert not callbacks
        frame();verify(1);cases+=1
        # Idle frames must not keep allocating/rebuilding.
        count=len(allocations);frame();frame();verify(1);assert len(allocations)==count;cases+=1
    # A Lua-owned child can be appended after our children, then removed/freed.
    script_child=0x404000;script=0x405000;script_value=0x406000
    u.mem_map(script_child,0x3000);name(script_child,'Other ESP')
    se=script_child+0x400;store(u,script_child+0x80,se);store(u,script_child+0x84,se+4);store(u,se,script)
    source(script,script_value,'World option');store(u,script_value,0x33)
    store(u,vchildren+52,script_child);store(u,visuals+0x74,vchildren+56)
    frame();verify(1);assert word(u,script_value)==0x33;cases+=1
    store(u,visuals+0x74,vchildren+52);u.mem_unmap(script_child,0x3000)
    frame();verify(1);cases+=1
    # Exact Helper activation adds a category, unloading it removes that category
    # and returns to World without touching the unrelated player ESP settings.
    script_child=0x404000;script=0x405000;script_value=0x406000
    u.mem_map(script_child,0x3000);name(script_child,'Other ESP')
    se=script_child+0x400;store(u,script_child+0x80,se);store(u,script_child+0x84,se+4);store(u,se,script)
    source(script,script_value,'Helper');store(u,script_value,1)
    store(u,vchildren+52,script_child);store(u,visuals+0x74,vchildren+56)
    frame();assert bytes(u.mem_read(word(u,controls+16)+0x15,1))==b'\1'
    call(u,exp('choose_category_probe'),[4]);assert call(u,exp('lifecycle_status_probe'))==1025
    assert word(u,script_value)==1;cases+=1
    store(u,visuals+0x74,vchildren+52);u.mem_unmap(script_child,0x3000)
    frame();assert bytes(u.mem_read(word(u,controls+16)+0x15,1))==b'\0'
    assert call(u,exp('lifecycle_status_probe'))==513
    call(u,exp('choose_category_probe'),[1]);verify(1);cases+=1
    # A World/custom-sky-style Lua textbox must not roll Visuals back to stock.
    script=0x401000;u.mem_map(script,0x1000);source(script,0,'Script text',10)
    def text(at,value):
        store(u,at+0x64,len(value));u.mem_write(at+0x68,(value+'\0').encode('utf-16le'))
    def get_text(at):return bytes(u.mem_read(at+0x68,word(u,at+0x64)*2)).decode('utf-16le')
    text(script,'sky_custom');store(u,elements+4,script);store(u,original+0x84,elements+8)
    frame();assert call(u,exp('lifecycle_status_probe'))==257
    text_views=[]
    for panel in [0,2]:
        c=word(u,children+4*panel);entries=word(u,c+0x80);assert word(u,c+0x84)==entries+8
        view=word(u,entries+4);assert get_text(view)=='sky_custom';text_views.append(view)
    text(text_views[0],'sky_edited');frame();assert get_text(script)=='sky_edited' and get_text(text_views[1])=='sky_edited'
    assert callbacks==[('value',script)];callbacks.clear()
    text(script,'sky_config');frame();assert all(get_text(v)=='sky_config' for v in text_views) and not callbacks
    store(u,script+0x60,1);text(text_views[0],'sky_locked');frame();assert get_text(script)=='sky_config'
    store(u,script+0x60,0);frame();assert get_text(script)=='sky_locked';callbacks.clear()
    store(u,original+0x84,elements+4);u.mem_unmap(script,0x1000);frame();verify(1);cases+=5
    # Unsupported third-party controls retain the original interface safely;
    # unloading that script recovers categories rather than disabling them forever.
    script=0x401000;u.mem_map(script,0x1000);source(script,0,'Unsupported',6)
    store(u,elements+4,script);store(u,original+0x84,elements+8)
    frame();assert call(u,exp('lifecycle_status_probe'))==258
    count=len(allocations);frame();assert len(allocations)==count
    store(u,original+0x84,elements+4);u.mem_unmap(script,0x1000)
    frame();verify(1);cases+=1
    # Native model rebinding must be adopted without writing over its value.
    replacement=native_value+16;store(u,replacement,0x75);store(u,native_source+0x5c,replacement)
    frame();assert call(u,exp('lifecycle_status_probe'))==257;assert word(u,replacement)==0x75
    for panel in [0,2]:
        view=word(u,word(u,word(u,children+4*panel)+0x80));assert word(u,view+0x5c)==replacement
    cases+=1
    # Forward through the real bound callback to the original core object.
    call(u,exp('lifecycle_callback_probe'),[0]);assert callbacks==[('config',native_source),('value',native_source)]
    assert len(created)-len(destroyed)==2
    # Even removal of one of our own children must be detected before sync.
    # The source topology itself has not changed in this case.
    callbacks.clear();removed=word(u,children)
    for i in range(1,12):store(u,vchildren+4*i,word(u,vchildren+4*(i+1)))
    store(u,visuals+0x74,vchildren+48);u.mem_unmap(removed,0x1000)
    frame();assert call(u,exp('lifecycle_status_probe'))==258
    assert bytes(u.mem_read(original+0x15,1))==b'\1';cases+=1
    return cases
