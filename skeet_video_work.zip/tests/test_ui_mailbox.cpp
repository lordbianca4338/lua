// Production mailbox with mock SDK storage and native entry points, no game.
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cwchar>
#include <memory>
#include <string>
#include <vector>
#define __fastcall
#include "../source/skeet/sticker_state.h"
#include "../source/skeet/night_mode.h"
namespace SkeetSDK {
enum {UiCheckbox=3,UiSlider=5};
struct Call {void* ecx;void(*function)(void*,void*);Call(void* p,decltype(function) f):ecx(p),function(f){}};
struct Checkbox {struct {int Type;} Header;std::shared_ptr<std::wstring> Name;int* Value=nullptr;std::vector<Call> Calls;template<class T>T* GetAs(){return reinterpret_cast<T*>(this);}};
using Slider=Checkbox;
struct Child {std::vector<Checkbox*> Elements;};struct Tab{std::vector<Child*> Childs;};struct CMenu{std::vector<Tab*> Tabs;};
}
namespace native_ui_names {void decode(const std::wstring* name,wchar_t* out,unsigned n){std::wcsncpy(out,name->c_str(),n);out[n-1]=0;}}
namespace ui_addon {struct Telemetry {unsigned size=28,valid=15;float cpu_percent=37,cpu_ghz=3.8f,ram_used_gib=5,ram_total_gib=16,process_mib=500;};}
night_mode::State night;unsigned modules=0,beats=0;std::string sky_value;unsigned sky_color=0;
void clover_ui_heartbeat(){++beats;}
void clover_ui_module(unsigned mask){modules|=mask;}
void clover_night(int on,unsigned amount,unsigned world,unsigned props){night.configure({on!=0,amount,world,props});}
void clover_night_reset(){night.reset();}
int clover_telemetry(void* out,unsigned){*static_cast<ui_addon::Telemetry*>(out)={};return 1;}
int clover_selected_weapon(){return 9;}
int clover_sticker_set(int w,unsigned slot,int id,float wear,float scale,float rot){return sticker_state::set(w,slot,{id,wear,scale,rot});}
int clover_sticker_get(int w,unsigned slot,void* out){if(!sticker_state::gun(w)||slot>=4)return 0;*static_cast<sticker_state::Sticker*>(out)=sticker_state::weapons[w].slots[slot];return 1;}
int clover_sky(const char* name){sky_value=name;return 1;}
int clover_sky_tint(const char* name,unsigned color){sky_value=name?name:"";sky_color=color;return 1;}
#include "../source/skeet/ui_addon_mailbox.h"
int main(){
 using namespace SkeetSDK;namespace box=ui_addon::mailbox;
 CMenu menu;Tab tab;Child child;menu.Tabs.resize(9);menu.Tabs[8]=&tab;tab.Childs.push_back(&child);
 Checkbox rows[42];int values[42]{};
 for(int i=0;i<42;i++){rows[i].Header.Type=i?UiSlider:UiCheckbox;rows[i].Value=&values[i];std::wstring name=i==0?L"Clover bridge request 8802":i==1?L"Clover bridge ready 8802":i<34?L"Clover bridge in "+std::to_wstring(i-2):L"Clover bridge out "+std::to_wstring(i-34);rows[i].Name=std::make_shared<std::wstring>(name);child.Elements.push_back(&rows[i]);}
 child.Elements.pop_back();box::frame(&menu);assert(!box::bound&&values[1]==0);
 child.Elements.push_back(&rows[41]);box::frame(&menu);assert(box::bound&&values[1]==8802&&rows[0].Calls.size()==1);
 auto run=[&](int op,std::initializer_list<int> args){static int seq=0;for(int i=1;i<7;i++)values[i+2]=0;int i=1;for(int a:args)values[2+i++]=a;values[2]=op;values[33]=++seq;for(auto c:rows[0].Calls)c.function(c.ecx,&rows[0]);assert(values[41]==seq);return values[34];};
 assert(run(0,{})==8802);assert(run(1,{})==1&&beats==1);run(2,{15});assert(modules==15);
 run(3,{1,85,0x735a50,0x917d73});assert(night.settings.enabled&&night.settings.amount==85&&night.settings.world==0x735a50);
 run(3,{0,85,0x735a50,0x917d73});assert(!night.settings.enabled);run(4,{});assert(night.resetting);
 assert(run(5,{})==1&&values[35]==15&&values[37]==38000);assert(run(6,{})==9);
 const int id=sticker_catalog::kits[1].id;
 for(int slot=0;slot<4;slot++){assert(run(7,{9,slot,id,3000,15000,-600000})==1);assert(run(8,{9,slot})==1&&values[35]==id&&values[36]==3000&&values[37]==15000&&values[38]==-600000);}
 assert(run(7,{9,0,0,0,10000,0})==1);assert(run(8,{9,0})==1&&values[35]==0);
 assert(run(7,{508,0,id,0,10000,0})==0);assert(run(8,{9,4})==0);assert(run(999,{})==0);
 std::string name="sky_cs15_daylight04_hdr";
 for(unsigned n=0;n<24;n++){unsigned v=0;for(unsigned j=0;j<4;j++)if(n*4+j<name.size())v|=unsigned(name[n*4+j])<<(j*7);values[2+7+n]=int(v);}
 assert(run(9,{})==1&&sky_value==name);assert(run(10,{0xabcdef})==1&&sky_color==0xabcdef&&sky_value==name);
 for(unsigned n=0;n<24;n++)values[2+7+n]=0;run(10,{0});assert(sky_value.empty());
 box::frame(&menu);assert(rows[0].Calls.size()==1);
 rows[0].Calls.clear();values[1]=0;box::frame(&menu);assert(rows[0].Calls.size()==1&&values[1]==8802);
 assert(run(0,{})==8802);
 child.Elements.clear();box::frame(&menu);assert(!box::bound);
}
