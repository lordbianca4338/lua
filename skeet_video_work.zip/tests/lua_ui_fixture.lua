bridge_addresses={}
-- Restricted GameSense API fixture. No game, OS FFI, filesystem or network calls.
now=0;chosen_weapon=9;controls={};events={};draws={};errors={};skies={};sky_tints={};db={};stickers={}
local function control(kind,tab,group,name,...)
 if tab=='SKINS' and fixture_skin_group then assert(group==fixture_skin_group,'Unknown Skinchanger container') end
 local args={...};local ref={kind=kind,tab=tab,group=group,name=name,visible=true,options=args}
 if kind=='checkbox' then ref.value=false elseif kind=='slider' then ref.value=args[3] elseif kind=='color' then ref.value=args elseif kind=='combo' then ref.value=args[1] elseif kind=='list' then ref.value=0 elseif kind=='multi' then ref.value={} else ref.value='' end
 controls[#controls+1]=ref;return ref
end
ui={}
for name,kind in pairs({new_checkbox='checkbox',new_slider='slider',new_color_picker='color',new_combobox='combo',new_listbox='list',new_multiselect='multi',new_textbox='text',new_label='label'}) do ui[name]=function(...) return control(kind,...) end end
function ui.new_string(name,default) local r=control('text','','',name);r.value=default;r.visible=false;return r end
function ui.reference(tab,group,name) local r=control('combo',tab,group,name,'100%');return r end
function ui.get(r) if r.kind=='color' then return unpack(r.value) end return r.value end
function ui.set(r,...)
 local args={...};if r.kind=='multi' or r.kind=='color' then r.value=args else r.value=args[1] end
 if r.native_callback then r.native_callback(r) end
 if r.callback then r.callback(r) end
end
function ui.update(r,...) r.options={...} end
function ui.set_visible(r,v) r.visible=v end
function ui.set_callback(r,fn) r.callback=fn end
function ui.is_menu_open() return true end
client={}
function client.set_event_callback(name,fn) events[name]=events[name] or {};table.insert(events[name],fn) end
function client.error_log(x) errors[#errors+1]=x end
function client.screen_size() return 1920,1080 end
function client.unix_time() return math.floor(now) end
function client.system_time() return 12,34,56 end
function client.latency() return .025 end
function client.userid_to_entindex(x) return x end
function fire(name,e) for _,f in ipairs(events[name] or {}) do f(e or {}) end end
function find(name) for _,r in ipairs(controls) do if r.name==name then return r end end error('missing control '..name) end
local system={ [0]={[78]=function() return nil end} }
function client.create_interface() return system end
local native={}
module_mask=0;night_calls={}
function native.clover_ui_module(mask) module_mask=bit.bor(module_mask,mask) end
function native.clover_night(on,amount,world,props) night_calls[#night_calls+1]={on,amount,world,props} end
function native.clover_night_reset() end
function native.clover_ui_heartbeat() end
function native.clover_selected_weapon() return chosen_weapon end
local guns={[7]=true,[9]=true,[40]=true}
function native.clover_sticker_get(w,s,out)
 if not guns[w] or s<0 or s>=4 then return 0 end
 local st=stickers[w] and stickers[w][s] or {id=0,wear=0,scale=1,rotation=0}
 out[0]={id=st.id,wear=st.wear,scale=st.scale,rotation=st.rotation};return 1
end
function native.clover_sticker_set(w,s,id,wear,scale,rot)
 if not guns[w] or s<0 or s>=4 then return 0 end
 stickers[w]=stickers[w] or {};stickers[w][s]={id=id,wear=wear,scale=scale,rotation=rot};return 1
end
function native.clover_telemetry(out,size)
 out[0]={valid=15,cpu_percent=37,cpu_ghz=3.8,ram_used_gib=5,ram_total_gib=16,process_mib=500};return 1
end
function native.clover_sky(name) skies[#skies+1]=name;return 1 end
function native.clover_sky_tint(name,color) sky_tints[#sky_tints+1]={name=name,color=color};return 1 end
local ffi={}
function ffi.cdef() end
function ffi.new(typename) return {[0]={id=0,wear=0,scale=1,rotation=0,valid=0}} end
-- ffi.load is unavailable in the game sandbox.
function ffi.sizeof() return 28 end
function ffi.typeof(t) return t end
function ffi.cast(t,v) if type(v)=='number' and bridge_addresses[v] then return native[bridge_addresses[v]] end;return v end
function ffi.string(x) return x end
package.preload.ffi=function() return ffi end
renderer={}
function renderer.measure_text(flags,s) return #tostring(s)*6,12 end
function renderer.text(x,y,r,g,b,a,flags,w,s) draws[#draws+1]=tostring(s) end
function renderer.rectangle() end
function renderer.gradient() end
function renderer.indicator() end
panorama={open=function() return {MyPersonaAPI={GetName=function() return 'Tester' end}} end}
globals={realtime=function() return now end,absoluteframetime=function() return 1/144 end,frametime=function() return 1/144 end,tickcount=function() return math.floor(now*64) end}
entity={get_local_player=function() return nil end,get_player_resource=function() return nil end,get_prop=function() return 75 end,get_player_name=function() return 'Enemy' end,is_enemy=function() return true end}
database={read=function(k) return db[k] end,write=function(k,v) db[k]=v end}
cvar=setmetatable({}, {__index=function(t,k) local v={value=k=='sv_skyname' and 'sky_map_default' or 'legacy_'..k};function v:get_string() return self.value end;function v:set_string(x) self.value=x end;rawset(t,k,v);return v end})

-- Native UI mailbox fixture. FFI is deliberately completely unavailable.
package.preload.ffi=function() error('FFI calls are forbidden in this fixture') end
function fixture_connect_bridge()
 local request=find('Clover bridge request 8802')
 find('Clover bridge ready 8802').value=8802
 request.native_callback=function()
  local function arg(i) return find('Clover bridge in '..i).value end
  local function put(i,v) find('Clover bridge out '..i).value=v end
  local function fixed(v) return math.floor(v*10000+.00001) end
  local function text()
   local t={};for n=0,23 do local v=arg(7+n);for j=0,3 do local c=math.floor(v/128^j)%128;if c==0 then return table.concat(t) end;t[#t+1]=string.char(c) end end;return table.concat(t)
  end
  for i=0,6 do put(i,0) end
  local op=arg(0);local result=1
  if op==0 then result=8802
  elseif op==1 then native.clover_ui_heartbeat()
  elseif op==2 then native.clover_ui_module(arg(1))
  elseif op==3 then native.clover_night(arg(1),arg(2),arg(3),arg(4))
  elseif op==4 then native.clover_night_reset()
  elseif op==5 then local t={};result=native.clover_telemetry(t,28);t=t[0];put(1,t.valid);put(2,fixed(t.cpu_percent));put(3,fixed(t.cpu_ghz));put(4,fixed(t.ram_used_gib));put(5,fixed(t.ram_total_gib));put(6,fixed(t.process_mib))
  elseif op==6 then result=native.clover_selected_weapon()
  elseif op==7 then result=native.clover_sticker_set(arg(1),arg(2),arg(3),arg(4)/10000,arg(5)/10000,arg(6)/10000)
  elseif op==8 then local t={};result=native.clover_sticker_get(arg(1),arg(2),t);if result==1 then t=t[0];put(1,t.id);put(2,fixed(t.wear));put(3,fixed(t.scale));put(4,fixed(t.rotation)) end
  elseif op==9 then result=native.clover_sky(text())
  elseif op==10 then local name=text();result=native.clover_sky_tint(name~='' and name or nil,arg(1))
  else result=0 end
  put(0,result);put(7,arg(31))
 end
end
