from pathlib import Path
from lupa.luajit21 import LuaRuntime

root = Path(__file__).resolve().parents[1]
lua = LuaRuntime(unpack_returned_tuples=True)
lua.execute((root / 'tests/lua_ui_fixture.lua').read_text())
lua.execute((root / 'source/lua/clover_cs2_ui_8802.lua').read_text())
lua.execute('''
fixture_connect_bridge(); fire('paint_ui'); assert(#errors == 0)
local toggle, choice = find('Override skybox'), find('Skybox')
assert(not choice.visible)
ui.set(toggle, true); assert(choice.visible)
ui.set(choice, 15); ui.set(find('Sky color'),10,20,30,255); now=1; fire('paint_ui')
assert(skies[#skies] == 'sky_csgo_night02')
assert(sky_tints[#sky_tints].name=='sky_csgo_night02' and sky_tints[#sky_tints].color==10+20*256+30*65536)
ui.set(toggle, false); now=2; fire('paint_ui')
assert(skies[#skies] == 'sky_map_default'); assert(not choice.visible)
assert(sky_tints[#sky_tints].name==nil)
local sky3d=find('Remove 3D Sky'); local original=cvar.r_3dsky:get_string()
ui.set(sky3d,true); now=3; fire('paint_ui'); assert(cvar.r_3dsky:get_string()=='0')
ui.set(sky3d,false); now=4; fire('paint_ui'); assert(cvar.r_3dsky:get_string()==original)
assert(#errors == 0)
''')
print('PASS: sky selection, visibility and restoration')
