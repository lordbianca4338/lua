from pathlib import Path
from lupa.luajit21 import LuaRuntime
r=Path(__file__).resolve().parents[1];lua=LuaRuntime(unpack_returned_tuples=True)
lua.execute((r/'tests/lua_ui_fixture.lua').read_text())
lua.execute((r/'source/lua/clover_cs2_ui_8802.lua').read_text())
lua.execute('''fixture_connect_bridge();fire('paint_ui');assert(module_mask==13);assert(#errors==0)
for _,name in ipairs({'Night mode','Override sky','Sticker slot','Find sticker'}) do local ok=pcall(find,name);assert(not ok,name) end
local logs=find('Draw logs');local watermark=find('Watermark');assert(logs.tab=='VISUALS' and watermark.tab=='VISUALS')
local events=ui.get(find('Log events'));assert(#events==3 and events[1]=='Hit' and events[2]=='Miss' and events[3]=='Purchase')
ui.set(find('Override fog'),true);ui.set(find('Fog start'),200);ui.set(find('Fog end'),120);now=1;fire('paint_ui');assert(cvar.fog_start.value=='200' and cvar.fog_end.value=='201')
ui.set(find('Override fog'),false);now=2;fire('paint_ui');assert(cvar.fog_start.value=='legacy_fog_start')
ui.set(logs,true);fire('aim_fire',{id=1,damage=80,hitgroup=1,hit_chance=75,tick=630,target=2});fire('aim_hit',{id=1,target=2,damage=80,hitgroup=1});now=3;fire('paint_ui');assert(table.concat(draws,'|'):find('Enemy',1,true))
assert(#errors==0)
''')
print('PASS: logs and watermark, all log events, removed controls, fog lifecycle, no FFI')
