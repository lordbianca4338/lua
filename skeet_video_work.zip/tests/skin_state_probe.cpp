#include <windows.h>
#include "../source/skeet/skin_native_client.h"
extern "C" {
__declspec(dllexport) unsigned skin_native_snapshot_probe(void* tab,void* out,unsigned capacity){skin_native_state::Raw raw{};skin_native_state::Rows rows{};if(!skin_native_client::read(tab,raw)||!skin_native_state::decode(raw,rows))return 0xffffffffu;if(capacity<rows.count)return 0xfffffffeu;std::memcpy(out,rows.data.data(),rows.count*sizeof(local_inventory::Spec));return rows.count;}
__declspec(dllexport) unsigned skin_native_active_probe(void* tab){return skin_native_client::active_source(tab);}
__declspec(dllexport) unsigned skin_native_spec_size_probe(){return sizeof(local_inventory::Spec);}
}
