#!/usr/bin/env python3
"""Closed x86 scan-worker hook, register/FP preservation, native point copy/retry.
No game startup, protected entry point, networking or supplied executable runs.
"""
from pathlib import Path
import json,struct,subprocess,hashlib,os,sys
import pefile
from record_fixture import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build'
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/body_preference_plan.cpp'),'-o',str(BUILD/'body_preference_plan')],check=True)
subprocess.run([str(BUILD/'body_preference_plan'),str(ROOT/'source/skeet/Binary/skeet_cv.bin'),str(BUILD/'body_preference.bin')],check=True)
if '--reuse-probe' not in sys.argv:
 env=os.environ.copy();cache=Path('/workspace/skeet-motion-bt-8802/.cache/global')
 env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(cache if cache.exists() else ROOT/'.cache/global'))
 with (BUILD/'body_preference_probe.log').open('w') as log:
  subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++23','-O1','-shared',
   '-I',str(ROOT/'source/compat'),'-I',str(ROOT/'source/skeet'),str(ROOT/'tests/body_preference_probe.cpp'),
   '-o',str(BUILD/'body_preference_probe.dll')],env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
pe=pefile.PE(str(BUILD/'body_preference_probe.dll'));pb=pe.OPTIONAL_HEADER.ImageBase
helper=next(pb+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name and b'body_bridge_probe' in s.name)
blob=(BUILD/'body_preference.bin').read_bytes();assert len(blob)==103
cases=0;retries=0
for health in [35,100]:
 for body_damage in [34,35,99,100,110]:
  for hitgroup in [2,3,6]:
   u=fixture();u.mem_map(pb,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(pb,pe.get_memory_mapped_image())
   imports={};u.mem_map(0x130000,0x4000)
   for lib in pe.DIRECTORY_ENTRY_IMPORT:
    for item in lib.imports:
     target=0x130000+len(imports)*16;store(u,item.address,target);imports[target]=item.name.decode()
   def crt(u,a,size,user):
    if a not in imports:return
    sp=u.reg_read(UC_X86_REG_ESP);name=imports[a]
    assert name in ['memcpy','memmove'],name
    dst,src,n=[word(u,sp+k) for k in [4,8,12]];u.mem_write(dst,bytes(u.mem_read(src,n)))
    u.reg_write(UC_X86_REG_EAX,dst);u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+4)
   u.hook_add(UC_HOOK_CODE,crt)
   code=bytearray(blob[:96]);pos=code.index(bytes.fromhex('b878563412'))+1;struct.pack_into('<I',code,pos,helper)
   location=0x50000000;u.mem_map(location,4096);u.mem_write(location,bytes(code));u.mem_write(BASE+0x50774,blob[96:])
   job,shooter,pool,frame=MEM+0x80000,MEM+0x90000,MEM+0xa0000,MEM+0xb0000
   store(u,job+8,health);store(u,shooter,0x400);store(u,frame+8,shooter)
   def point(ptr,group,damage):
    for off,v in [(0,fbits(100.)),(4,fbits(20.)),(8,fbits(50.)),(0xc,fbits(1.)),(0x10,fbits(2.)),(0x14,fbits(3.)),(0x18,55),(0x1c,damage),(0x20,0x123),(0x24,group),(0x28,0),(0x2c,fbits(.85)),(0x30,0x234),(0x34,0x14)]:store(u,ptr+off,v)
   point(pool,7,70);point(pool+56,hitgroup,body_damage)
   leg=bytes(u.mem_read(pool,56));torso=bytes(u.mem_read(pool+56,56))
   for off,val in [(0x18,pool),(0x28,0xff),(0x5c,job),(0x47e0,pool),(0x47e4,pool+112)]:store(u,SP+off,val)
   saved={UC_X86_REG_EBX:0x12345678,UC_X86_REG_ESI:0x23456789,UC_X86_REG_EDX:0x34567890,UC_X86_REG_EBP:frame}
   for reg,val in saved.items():u.reg_write(reg,val)
   u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_MXCSR,0x1f80)
   xmm={UC_X86_REG_XMM0+i:0x3f800001+i for i in range(8)}
   for reg,val in xmm.items():u.reg_write(reg,val)
   run_until(u,BASE+0x50774,BASE+0x5077b,200000)
   promoted=hitgroup in [2,3] and body_damage>=health
   assert word(u,SP+0x18)==pool+(56 if promoted else 0)
   assert u.reg_read(UC_X86_REG_ESP)==SP and u.reg_read(UC_X86_REG_ECX)==1 and u.reg_read(UC_X86_REG_EDI)==job
   assert all(u.reg_read(reg)==val for reg,val in saved.items())
   assert all(u.reg_read(reg)==val for reg,val in xmm.items()) and u.reg_read(UC_X86_REG_MXCSR)==0x1f80
   run_until(u,BASE+0x5077b,BASE+0x50869)
   assert bytes(u.mem_read(job+0xc,56))==(torso if promoted else leg)
   if promoted:
    assert word(u,job)&8 and bytes(u.mem_read(job+0x44,56))==leg
    # Execute the original HC-failure retry branch from the actual native caller.
    store(u,SP+0x18,job);store(u,SP+0x14,shooter);store(u,SP+0xa0,MEM+0xc0000)
    u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_EDI,shooter)
    retried=[]
    def native_hc(u,a,size,user):
     if a!=0x4341b4c2:return
     sp=u.reg_read(UC_X86_REG_ESP)
     assert [word(u,sp+4),word(u,sp+8)]==[shooter,job]
     assert bytes(u.mem_read(job+0xc,56))==leg
     retried.append(True);store(u,word(u,sp+12),fbits(.8));u.reg_write(UC_X86_REG_EAX,1)
     u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+16)
    h=u.hook_add(UC_HOOK_CODE,native_hc)
    run_until(u,0x43354b62,0x43354bf4)
    u.hook_del(h);assert retried and not(word(u,job)&8);retries+=1
   cases+=1
report={'passed':True,'portable_selection_cases':1264,'native_hook_and_point_copy_cases':cases,
 'native_failed_hitchance_backup_retries':retries,'integer_and_sse_state_preserved':True,
 'point_payload_copied_by_native_code':True,'only_original_evaluated_pool_used':True,
 'priority_mask_preserved':True,'existing_alternates_preserved':True,'custom_backtrack_added':False,
 'new_prediction_horizon_added':False,'owned_instruction_bytes':7,'site':'0x43360774',
 'scope':'Native Rage scan worker first finalized point pool; lethal chest/stomach over selected leg, with native backup retry available',
 'core_sha256':hashlib.sha256(IMAGE).hexdigest(),'game_tested':False}
(BUILD/'body_preference_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
