#include "../source/skeet/local_inventory.h"
#include <vector>
#include <cassert>
#include <iostream>
using namespace local_inventory;
struct Fake {std::uint64_t id=0;unsigned position=0,account=0;Spec spec;};
static Session state{reinterpret_cast<void*>(1),reinterpret_cast<void*>(2),123,1,42};
static std::vector<Fake*> cache;static int created=0,destroyed=0,notifications=0,init_fail=0,insert_fail=0,notify_fail=0,remove_fail=0;
static bool session(Session& s){s=state;return true;}
static bool highest(const Session&,std::uint64_t& id,unsigned& pos){id=11;pos=8;for(auto* p:cache){if(p->id>id)id=p->id;if(p->position>pos)pos=p->position;}return true;}
static bool contains(const Session& s,void* object,std::uint64_t id){for(auto* p:cache)if(p==object)return p->id==id&&p->account==s.account;return false;}
static void* create(){++created;return new Fake;}
static bool initialize(void* ptr,const Session& s,const Spec& spec,std::uint64_t id,unsigned pos){auto* p=static_cast<Fake*>(ptr);*p={id,pos,s.account,spec};return !init_fail;}
static bool name(void* ptr,const char* n){std::strcpy(static_cast<Fake*>(ptr)->spec.name,n);return true;}
static bool insert(const Session&,void* p){if(insert_fail)return false;cache.push_back(static_cast<Fake*>(p));return true;}
static bool notify(const Session&,int,void*){++notifications;return !notify_fail;}
static bool remove(const Session&,void* p){if(remove_fail)return false;for(auto it=cache.begin();it!=cache.end();++it)if(*it==p){cache.erase(it);return true;}return false;}
static void destroy(void* ptr){++destroyed;delete static_cast<Fake*>(ptr);}
static Api api{session,highest,contains,create,initialize,name,insert,notify,remove,destroy};
int main() {
 unsigned cases=0;Spec s{};
 for(int w:{0,1,9,65535,65536})for(int seed:{-1,0,1000,1001})for(float wear:{-1.f,0.f,.5f,1.f,2.f}) {
  s.weapon=w;s.seed=seed;s.wear=wear;
  assert(valid(s)==(w>0&&w<65536&&seed>=0&&seed<=1000&&wear>=0&&wear<=1));cases++;
 }
 assert(valid_name(u8"Бабочка"));assert(!valid_name("\xc0\xaf"));assert(!valid_name("\xed\xa0\x80"));assert(!valid_name("\xf4\x90\x80\x80"));assert(!valid_name("bad\nname"));
 char long_name[34];std::memset(long_name,'a',33);long_name[33]=0;assert(!valid_name(long_name));cases+=6;
 Inventory inv;s={};int first=inv.add(api,s);assert(first==0&&inv.items[0].id==12&&cache.size()==1);cases++;
 auto* saved=cache[0];assert(inv.rename(api,0,u8"Дракон"));assert(std::strcmp(saved->spec.name,u8"Дракон")==0);cases++;
 assert(!inv.erase(api,127)&&!inv.erase(api,128));assert(cache.size()==1);cases+=2;
 remove_fail=1;int freed=destroyed;assert(!inv.erase(api,0)&&destroyed==freed&&inv.items[0].object==saved);remove_fail=0;cases++;
 assert(inv.erase(api,0)&&cache.empty()&&destroyed==freed+1);cases++;
 for(int* fail:{&init_fail,&insert_fail,&notify_fail}){*fail=1;freed=destroyed;assert(inv.add(api,s)==-1&&cache.empty()&&destroyed==freed+1);*fail=0;cases++;}
 assert(inv.add(api,s)==0);auto* stale=cache[0];cache.clear();delete stale;notifications=0;
 assert(!inv.rename(api,0,"stale")&&notifications==0&&!inv.items[0].object);cases++;
 assert(inv.add(api,s)==0);auto* previous=cache[0];cache.clear();state.account=84;state.owner=456;state.cache=reinterpret_cast<void*>(3);notifications=0;
 assert(!inv.rename(api,0,"other account")&&notifications==0&&!inv.items[0].object);delete previous;cases++;
 std::cout<<cases<<" inventory validation, ownership, rollback and account-switch cases passed\n";
}
