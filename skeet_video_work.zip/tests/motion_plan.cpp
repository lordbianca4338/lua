#include "../source/skeet/motion_plan.h"
#include <fstream>
#include <iterator>
#include <vector>
#include <iostream>
int main(int argc,char** argv) {
    if(argc!=7)return 2;
    std::ifstream in(argv[1],std::ios::binary);
    std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(in)),{});
    if(!scan_patch::matches_original(bytes.data(),bytes.size()))return 3;
    motion_plan::Plan plan{};
    const auto address=unsigned(std::stoul(argv[3],nullptr,0));
    const auto begin=unsigned(std::stoul(argv[4],nullptr,0));
    const auto apply=unsigned(std::stoul(argv[5],nullptr,0));
    const auto getter=unsigned(std::stoul(argv[6],nullptr,0));
    if(!motion_plan::make_plan(bytes.data(),bytes.size(),address,begin,apply,getter,plan))return 4;
    for(const auto& edit:plan.edits) {
        bytes[edit.offset]^=1;motion_plan::Plan invalid{};
        if(motion_plan::make_plan(bytes.data(),bytes.size(),address,begin,apply,getter,invalid))return 5;
        bytes[edit.offset]^=1;
    }
    std::ofstream out(argv[2],std::ios::binary);
    out.write(reinterpret_cast<const char*>(plan.code),sizeof(plan.code));
    for(const auto& e:plan.edits) {
        out.write(reinterpret_cast<const char*>(&e.offset),4);
        out.write(reinterpret_cast<const char*>(&e.length),4);
        out.write(reinterpret_cast<const char*>(e.after),e.length);
    }
    std::cout<<"Motion plan and incompatible-site checks passed\n";
}
