#include "../source/skeet/hitchance_override_patch.h"
#include <cassert>
#include <fstream>
#include <iterator>
#include <vector>
#include <iostream>
int main(int argc,char** argv){
 using namespace hitchance_override;
 for(unsigned id=0;id<65;id++)assert(!(settings[id].load()&1));
 unsigned cases=0;for(unsigned mode=0;mode<4;mode++)for(unsigned chance:{0u,1u,50u,100u}){Setting a{true,chance,5,mode};auto b=Setting::unpack(a.pack());assert(b.enabled&&b.chance==chance&&b.key==5&&b.mode==mode);std::atomic<unsigned> state{};bool first=active(state,a.pack(),false,true),pressed=active(state,a.pack(),true,true),held=active(state,a.pack(),true,true),released=active(state,a.pack(),false,true);assert(pressed==held);if(mode==0)assert(first&&pressed&&released);if(mode==1)assert(!first&&pressed&&!released);if(mode==2){assert(!first&&pressed&&released);assert(!active(state,a.pack(),true,true));}if(mode==3)assert(first&&!pressed&&released);assert(!active(state,a.pack(),false,false));cases++;}
 Setting global{true,80,5,1},awp{true,90,6,1};settings[0]=global.pack();settings[9]=awp.pack();assert(effective_profile(9)==9&&effective_profile(40)==0);settings[9]=Setting{}.pack();assert(effective_profile(9)==0);
 if(argc==4){std::ifstream in(argv[1],std::ios::binary);std::vector<unsigned char> image((std::istreambuf_iterator<char>(in)),{});const auto address=unsigned(std::stoul(argv[3],nullptr,0));const auto scan=scan_patch::make_plan(address+0x2000,0x23b000,0x23b004);std::memcpy(image.data()+scan_patch::guard_call,scan.guard,5);std::memcpy(image.data()+scan_patch::threshold_call,scan.threshold,6);precision_patch::Plan precision{};assert(precision_patch::make_plan(image.data(),image.size(),address+0x1000,0x23b008,0x23b004,precision));for(auto e:precision.edits)std::memcpy(image.data()+e.offset,e.after,e.size);hitchance_override_patch::Plan p{};assert(hitchance_override_patch::make(image.data(),image.size(),address,0x100600,p));for(unsigned i=0;i<3;i++)std::memcpy(image.data()+hitchance_override_patch::sites[i],p.edits[i],hitchance_override_patch::lengths[i]);std::ofstream out(argv[2],std::ios::binary);out.write(reinterpret_cast<const char*>(p.code),256);out.write(reinterpret_cast<const char*>(precision.code),1024);out.write(reinterpret_cast<const char*>(image.data()),image.size());}
 std::cout<<cases<<" override mode/policy cases passed\n";
}
