#include <windows.h>
#include "../source/skeet/motion_patch.h"
#include "../source/skeet/precision_patch.h"
using namespace motion_records;
extern "C" {
__declspec(dllexport) int production_extrapolation_probe(){return motion_patch::options().extrapolation;}
__declspec(dllexport) Scratch probe_scratch{};
static Options configured{1,1,8,1,2};
__declspec(dllexport) void initialize_probe(unsigned blend,unsigned sweep) {
    motion_patch::tls_slot=7;
    scan_patch::application_return=0x100000;
    motion_patch::api={reinterpret_cast<Blend>(blend),reinterpret_cast<Sweep>(sweep)};
}
// Variable policy exists only in this test DLL. Production options() is fixed.
__declspec(dllexport) void options_probe(int consistent,int interpolation,int gap,int extrapolation,int horizon) {
    configured={consistent,interpolation,gap,extrapolation,horizon};
}
__declspec(dllexport) void begin_probe(void* context,unsigned* args){motion_patch::begin(context,args);}
__declspec(dllexport) void configured_begin_probe(void* context,unsigned* args) {
    auto* s=motion_patch::scratch();if(!s)return;
    int low=args[4],high=args[5];
    if(motion_records::begin(*s,reinterpret_cast<void*>(args[1]),reinterpret_cast<void*>(args[2]),context,
        configured,motion_patch::clock(context),low,high,args[0]==0x4332ff6b)) {args[4]=low;args[5]=high;}
}
__declspec(dllexport) const int* fixed_flag_probe(int n) {
    return n==0?&scan_patch::history_guard_enabled:(n==1?&scan_patch::strict_threshold_enabled:&precision_patch::enabled);
}
__declspec(dllexport) int __fastcall getter_probe(const void* h,int t,int bone,void* o,void* m) {
    return motion_patch::getter(h,t,bone,o,m);
}
__declspec(dllexport) int apply_probe(void* frame,void* ebp){return motion_patch::apply_prepared(frame,ebp);}
__declspec(dllexport) unsigned scratch_size_probe(){return sizeof(Scratch);}
__declspec(dllexport) int trace_probe(void* actor,Vec from,Vec to){return motion_trace::sweep(actor,from,to);}
__declspec(dllexport) void trace_engine_probe(void* engine){motion_trace::engine=engine;}
}
