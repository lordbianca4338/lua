#include "../source/skeet/night_mode.h"
#include <cassert>
#include <iostream>
using namespace night_mode;
struct Mat {Group group=Group::Other;float c[3]{1,1,1};int refs=0;};static Mat materials[200];
unsigned short first(){return 0;}unsigned short next(unsigned short h){return h==199?0xffff:h+1;}void* get(unsigned short h){return &materials[h];}
bool read(void* p,float* c){auto& m=*static_cast<Mat*>(p);std::copy(m.c,m.c+3,c);return true;}
bool describe(void* p,Group& g,float* c){g=static_cast<Mat*>(p)->group;return read(p,c);}
void hold(void* p){static_cast<Mat*>(p)->refs++;}void release(void* p){static_cast<Mat*>(p)->refs--;}void write(void* p,const float* c){std::copy(c,c+3,static_cast<Mat*>(p)->c);}
static State state;int main(){Api api{first,next,get,describe,hold,release,read,write};for(unsigned i=0;i<200;i++)materials[i].group=i%3==0?Group::Other:(i%3==1?Group::World:Group::Props);
 state.configure({true,100,0x202020,0x404040});for(unsigned n=0;n<20;n++)assert(state.tick(api,n*16)<=64);
 assert(materials[0].c[0]==1&&materials[1].c[0]<.13&&materials[2].c[0]>.25&&materials[2].c[0]<.26);
 const unsigned held=state.used;for(unsigned n=1;n<20;n++)state.tick(api,2000+n*16);assert(state.used==held);
 state.configure({true,0,0xffffff,0xffffff});for(unsigned n=0;n<20;n++)assert(state.tick(api,3000+n*16)<=64);assert(materials[1].c[0]==1);
 state.configure({true,90,0x505050,0x606060});for(unsigned n=0;n<20;n++)state.tick(api,4000+n*16);
 materials[2].c[0]=.77f;state.configure({false,0,0,0});for(unsigned n=0;n<20;n++)assert(state.tick(api,5000+n*16)<=64);
 assert(state.used==0&&materials[1].c[0]==1&&materials[2].c[0]==.77f);for(auto& m:materials)assert(m.refs==0);
 state.configure({true,60,0x101010,0x505050});for(unsigned n=0;n<20;n++)state.tick(api,6000+n*16);state.reset();for(unsigned n=0;n<20;n++)assert(state.tick(api,7000+n*16)<=64);assert(state.used==held);
 state.configure({false,0,0,0});for(unsigned n=0;n<20;n++)state.tick(api,8000+n*16);for(auto& m:materials)assert(m.refs==0);
 std::cout<<"Night mode: bounded iteration, World/Props filters, palette changes, ref lifetime and conditional restoration passed\n";
}
