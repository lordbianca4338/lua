#include "../source/skeet/skin_menu_design.h"
#include <cassert>
#include <fstream>
#include <iostream>
int main(int argc,char** argv) {
    unsigned cases=0;
    for(float dpi:{.75f,1.f,1.25f,1.5f,2.f,3.f})for(int w:{620,660,800})for(int h:{480,640,720}) {
        auto p=skin_menu_design::layout(int(w*dpi),int(h*dpi),dpi);
        for(auto r:p)assert(r.x>=0&&r.y>=0&&r.w>0&&r.h>0&&r.x+r.w<=int(w*dpi)&&r.y+r.h<=int(h*dpi));
        assert(p[0].x==p[2].x&&p[0].w==p[2].w&&p[0].y+p[0].h<p[2].y);
        assert(p[1].x>p[0].x+p[0].w&&p[1].y==p[0].y&&p[1].y+p[1].h==p[2].y+p[2].h);++cases;
    }
    assert(skin_menu_design::route(L"Model options",L"Player model",0)==0);
    assert(skin_menu_design::route(L"Model options",L"Filter by weapon",0)==2);
    assert(skin_menu_design::route(L"Weapon skin",L"Quality",1)==1);
    assert(skin_menu_design::collection(L"Sir Bloody Silent Darryl"));
    assert(!skin_menu_design::collection(L"Unknown"));
    if(argc>1) {
        std::ofstream out(argv[1]);auto p=skin_menu_design::layout(660,640,1);
        out<<"{\"panels\":[";
        for(int i=0;i<3;i++){auto r=p[i];if(i)out<<',';out<<'['<<r.x<<','<<r.y<<','<<r.w<<','<<r.h<<']';}
        out<<"],\"geometry_cases\":"<<cases<<"}\n";
    }
    std::cout<<cases<<" Skinchanger geometry checks passed\n";
}
