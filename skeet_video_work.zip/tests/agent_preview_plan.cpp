#include "../source/skeet/agent_preview_plan.h"
#include <cassert>
#include <iostream>
int main(){
 using namespace agent_preview;Schedule s;Style a{},b{Material::Solid,0xff123456};
 assert(s.due(0,0,a));s.advance(0);s.submitted(0,0,a);
 for(unsigned t=1;t<33;t++)assert(!s.due(t,0,a));
 assert(s.due(33,0,a)&&s.due(1,1,a)&&s.due(1,0,b));
 assert(s.advance(50000)<=.101f);s.submitted(0xfffffff0,0,a);
 assert(!s.due(8,0,a)&&s.due(30,0,a));s.pause();assert(s.due(0,0,a));
 const auto before=s.animation;s.advance(200000);assert(s.animation==before);
 for(bool w:{false,true}){
  const auto v=view(w),p=projection(w);for(float x:v.v)assert(std::isfinite(x));for(float x:p.v)assert(std::isfinite(x));
  assert(p.v[0]>p.v[5]&&p.v[14]==-1&&v.v[11]<0);
 }
 std::cout<<"Timing, pause/resume, tick wrap and camera matrices passed\n";
}
