#include "../source/skeet/precision_patch.h"
#include "../source/skeet/motion_plan.h"
#include "../source/skeet/body_preference_patch.h"
#include "../source/skeet/crouch_multipoint_patch.h"
#include "../source/skeet/hitchance_override_patch.h"
#include <fstream>
#include <iterator>
#include <vector>
#include <cassert>
#include <iostream>
int main(int argc,char** argv) {
    if(argc!=2)return 2;
    std::ifstream in(argv[1],std::ios::binary);
    const std::vector<unsigned char> original((std::istreambuf_iterator<char>(in)),{});
    assert(scan_patch::matches_original(original.data(),original.size()));
    for(unsigned address:{0x10000000u,0x60000000u,0xf0000000u}) {
        auto image=original;std::vector<bool> owned(image.size(),false);
        const auto write=[&](unsigned at,const unsigned char* bytes,unsigned n){
            for(unsigned i=0;i<n;i++){assert(!owned.at(at+i));owned[at+i]=true;image[at+i]=bytes[i];}
        };
        assert(scan_patch::compatible_sites(image.data(),image.size()));
        const auto scan=scan_patch::make_plan(address,0x200000,0x200004);
        write(scan_patch::guard_call,scan.guard,5);write(scan_patch::threshold_call,scan.threshold,6);
        precision_patch::Plan precision{};
        assert(precision_patch::make_plan(image.data(),image.size(),address+0x1000,0x200008,0x200004,precision));
        // The precision patch intentionally replaces the old threshold hook.
        for(unsigned i=0;i<6;i++)owned[scan_patch::threshold_call+i]=false;
        for(const auto& e:precision.edits)write(e.offset,e.after,e.size);
        motion_plan::Plan motion{};
        assert(motion_plan::make_plan(image.data(),image.size(),address+0x3000,0x300000,0x300010,0x300020,motion));
        for(const auto& e:motion.edits)write(e.offset,e.after,e.length);
        body_preference_patch::Plan body{};
        assert(body_preference_patch::make(image.data(),image.size(),address+0x5000,0x300030,body));
        write(body_preference_patch::site,body.jump,sizeof(body.jump));
        crouch_multipoint_patch::Plan crouch{};
        assert(crouch_multipoint_patch::make(image.data(),image.size(),address+0x7000,0x300050,0x300060,0x300070,crouch));
        for(unsigned i=0;i<2;i++)write(crouch_multipoint_patch::sites[i],crouch.calls[i],5);
        hitchance_override_patch::Plan override_plan{};assert(hitchance_override_patch::make(image.data(),image.size(),address+0x9000,0x300080,override_plan));
        for(unsigned i=0;i<3;i++)write(hitchance_override_patch::sites[i],override_plan.edits[i],hitchance_override_patch::lengths[i]);
        unsigned changed=0;
        for(unsigned i=0;i<image.size();i++) {if(!owned[i])assert(image[i]==original[i]);else changed++;}
        assert(changed==120);
        // All rolled-back selector/animation calls and the removed prediction
        // worker retain the exact original bytes after joint installation.
        for(unsigned site:{0x41a0bu,0x444f5u,0xb32a9u,0xb5cf2u,0xfeb67u,0x105024u})
            assert(!std::memcmp(image.data()+site,original.data()+site,5));
        assert(!std::memcmp(image.data()+0x4cd45,original.data()+0x4cd45,10));
        assert(precision_patch::sample_count==0x160+128*12);
        assert(precision_patch::snapshot>=precision_patch::sample_count+16);
        assert((precision_patch::frame_size&15)==8);
    }
    std::cout<<"Combined scan/precision/motion installation: 6 allocations, 120 owned instruction bytes; remaining image preserved.\n";
}
