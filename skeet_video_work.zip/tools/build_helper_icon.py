from pathlib import Path
import xml.etree.ElementTree as ET
from svgpathtools import parse_path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
root=ET.parse(ROOT/'data/icons/helper.svg').getroot()
paths=[parse_path(e.attrib['d']) for e in root if e.tag.rsplit('}',1)[-1]=='path']
assert len(paths)==1
p=paths[0];xmin,xmax,ymin,ymax=p.bbox();span=max(xmax-xmin,ymax-ymin)
im=Image.new('L',(384,384));draw=ImageDraw.Draw(im)
polys=[]
for part in p.continuous_subpaths():
 points=[]
 for seg in part:
  for i in range(24):
   z=seg.point(i/24);points.append(((z.real-(xmin+xmax)/2)/span*344+192,(z.imag-(ymin+ymax)/2)/span*344+192))
 area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(points,points[1:]+points[:1]))
 polys.append((abs(area),area,points))
polys.sort(reverse=True);sign=polys[0][1]>0
for _,area,pts in polys:draw.polygon(pts,fill=255 if (area>0)==sign else 0)
im=im.resize((96,96),Image.Resampling.LANCZOS)
im.save(ROOT/'Helper_icon_preview.png')
values=[min(16,(v*16+127)//255) for v in im.getdata()]
header='#pragma once\n#include <cstdint>\n// Coverage generated from data/icons/helper.svg, normalized to its full path bounds.\nnamespace helper_icon {inline constexpr std::uint8_t coverage[96*96]={\n'
header+='\n'.join(','.join(map(str,values[i:i+96]))+',' for i in range(0,len(values),96))+'\n};}\n'
(ROOT/'source/skeet/helper_icon_data.h').write_text(header)
print('Normalized SVG bounds:',(xmin,xmax,ymin,ymax))
